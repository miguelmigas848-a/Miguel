# Motion graphics com Remotion

O Remotion renderiza componentes React quadro a quadro para criar vídeos. O gargalo não é a qualidade do código: é a técnica de motion design. Uma geração sem direção produz easing linear, fades somente de opacidade, entradas simultâneas, cores chapadas e nenhuma textura. Esse é o visual de “vídeo genérico de IA”. Esta skill existe para evitar isso.

## Regras obrigatórias (aplique a TODA composição)

1. **NUNCA use interpolação linear.** Toda chamada a `interpolate()` recebe uma curva de easing; prefira `spring()` em todas as entradas. Sempre use `extrapolateLeft/Right: "clamp"`.
2. **Anime de 2 a 3 propriedades juntas nas entradas** (opacidade + `translateY` + escala). Um fade isolado é proibido.
3. **Aplique escalonamento a tudo.** Listas, palavras, raios, cards: intervalos de 3 a 6 quadros. Nada entra ao mesmo tempo.
4. **Inclua saídas e faça-as mais rápidas que as entradas** (cerca de 10 quadros, contra 20).
5. **Use cinco camadas em cada cena**, de baixo para cima: malha de fundo → recursos → gráficos/tipografia → gradação de cor → granulação + vinheta. Nunca use um fundo de cor chapada.
6. **Aplique Ken Burns a toda imagem estática** (escala lenta de 1 a 1,08 + movimento panorâmico). Para todo recurso de vídeo, use `<OffthreadVideo>`, nunca `<Video>`.
7. **Dê movimento sutil aos elementos parados**: qualquer elemento que fique na tela por mais de 2 s deve ter um micro movimento em onda senoidal.
8. **Derive todos os tempos de `fps`** por meio de `useVideoConfig()`. Não use números de quadros arbitrários.
9. **Mantenha um único objeto de tema** no início do projeto (cores, easings, predefinições de spring, fontes). Nunca coloque um código hexadecimal de cor ou easing diretamente em um componente.
10. **Renderize, extraia quadros, INSPECIONE-OS, corrija e renderize novamente.** Nunca entregue uma renderização sem verificar. Esse ciclo é obrigatório; consulte Verificação abaixo.

## Fluxo de trabalho

### Etapa 1 — Definição do escopo
Determine: duração, fps (30 por padrão; 60 somente para movimentos rápidos e intensos), dimensões (1080×1920 para Reels/Shorts, 1920×1080 para paisagem), recursos disponíveis (imagens, vídeos, áudio, logotipos) e se será uma composição nova ou uma edição de projeto existente. Se estiver editando um projeto existente, leia todo o conteúdo de `src/`, encontre o tema (ou crie um) e corrija as violações das regras acima antes de adicionar recursos.

### Etapa 2 — Configuração
Projeto novo:
```bash
npm install remotion @remotion/cli react react-dom
# opcional: @remotion/transitions @remotion/motion-blur @remotion/google-fonts
```
Copie `remotion/assets/theme.ts` desta skill para `src/theme.ts` e adapte a paleta à marca da pessoa. Estrutura: `src/index.ts` (`registerRoot`) → `src/Root.tsx` (`Composition`, duração/fps/tamanho) → `src/scenes/*.tsx` → `src/components/*.tsx`. Coloque os recursos da pessoa em `public/` e carregue-os com `staticFile()`.

### Etapa 3 — Criação
Leia `references/motion-patterns.md` para ver as implementações reutilizáveis dos componentes (BgMesh, Grade, Grain, Vignette, KenBurns, WordReveal, Stagger, Counter, Spark, transições e paralaxe). Componha as cenas a partir desses padrões. Para ritmo, cadência, tipografia, paletas de cores e regras de design de som, leia `references/design-rules.md`.

Ritmo da cena: IMPACTO → pausa (15–20 quadros estáticos) → construção → IMPACTO. Algo precisa se mover nos primeiros 15 quadros. Não passe de 90 quadros sem um novo elemento visual.

### Etapa 4 — Renderização
```bash
npx remotion render src/index.ts <CompId> out/video.mp4 --codec h264 --crf 17
```
O Remotion precisa de um binário do Chromium. Se o download automático falhar (ambientes isolados ou integração contínua sem conexão), encontre um binário e informe-o explicitamente:
```bash
which chromium chromium-browser google-chrome 2>/dev/null
ls /opt/pw-browsers 2>/dev/null   # as instalações do Playwright ficam aqui
npx remotion render ... --browser-executable=<path>
```
Se o Chrome completo apresentar o erro “Old Headless mode has been removed”, use um binário `headless_shell` (o Playwright inclui um em `chromium_headless_shell-*/chrome-linux/headless_shell`).

### Etapa 5 — VERIFICAÇÃO (obrigatória; nunca pule)
Extraia quadros dos momentos principais e inspecione cada um visualmente. O método portátil funciona em máquinas sem ffmpeg instalado no sistema e renderiza o quadro exato:
```bash
for f in 15 45 90 150; do
  npx remotion still src/index.ts <CompId> out/check_$f.png --frame $f --overwrite
done
```
Se o ffmpeg estiver instalado no sistema, extrair quadros do MP4 final também verifica a codificação (`-ss` é mais portátil que os filtros `select=`, cuja forma de escrever pode falhar em alguns terminais e no ffmpeg incluído com o Remotion):
```bash
ffmpeg -v error -ss 1.5 -i out/video.mp4 -frames:v 1 check_1.png
```
Procure os problemas abaixo e corrija-os nesta ordem de frequência:
- **Problemas de espaçamento**: `gap`/`margin` em `em` usa o tamanho da fonte do elemento PAI (geralmente 16 px), e não o tamanho do texto. Use valores em px nos containers flexíveis ao redor de textos grandes.
- Texto ultrapassando ou encostando nas bordas do quadro (em vídeos 9:16, mantenha o conteúdo essencial nos 75% centrais da altura, pois a interface da plataforma cobre a parte superior e inferior).
- Elementos visíveis antes da entrada ou depois da saída (falta de `clamp`).
- Falhas de cor/contraste: a cor principal em mais de um elemento por quadro ou texto apagado e ilegível sobre a gradação.
- Erros na ordem das camadas (granulação/vinheta deve ficar no topo; a gradação, acima do conteúdo).

Corrija → renderize de novo → extraia os quadros novamente → inspecione-os outra vez. Só entregue após uma verificação sem problemas. Em seguida, siga a lista final de conferência no fim de `references/design-rules.md`.

### Edição de gravações existentes da pessoa
Para melhorar um MP4 existente (legendas, gradação de cor, abertura/encerramento) em vez de criar um vídeo do zero: coloque o arquivo em `public/`, renderize-o como camada de recurso com `<OffthreadVideo src={staticFile("clip.mp4")} />`, defina a duração da composição com base na duração do clipe e coloque os gráficos/gradação/granulação sobre ele. Use `ffprobe` para obter a duração e o fps do clipe antes de configurar a composição. Para legendas sincronizadas palavra por palavra com a fala, consulte a seção de legendas em `references/motion-patterns.md`.

## Arquivos de referência
- `references/motion-patterns.md` — biblioteca de componentes para copiar e colar: fundos, gradação/granulação/vinheta, Ken Burns, revelação de texto, contadores, transições, paralaxe, sincronização de áudio e legendas. Leia antes de escrever componentes.
- `references/design-rules.md` — paletas, regras de tipografia, arquitetura de cenas, design de som e lista de conferência pré-entrega. Leia antes de criar o design e antes da entrega final.
- `remotion/assets/theme.ts` — modelo de tema para copiar para cada projeto.

## Erros comuns que devem ser evitados
- **Não use emojis como ícones.** Emojis são desenhados como glifos coloridos da plataforma (✳️ verde, 🌐 azul), ignoram a paleta e quebram silenciosamente a regra de uma única cor principal; além disso, aparecem sobre qualquer fundo escolhido (mascote laranja sobre bloco laranja = invisível). Desenhe glifos com CSS/SVG nas cores do tema ou confira cada emoji nos quadros extraídos.
- **A falta de recursos de efeitos sonoros não justifica entregar um vídeo sem áudio.** Gere um kit mínimo como arquivos WAV de 16 bits usando um script Node (whoosh de rajada de ruído, pop com queda de tom, kick/baixo senoidal, pad com seno desafinado) em `public/sfx/`. O auxiliar `../modelo/ferramentas/gerar-sfx.mjs` mostra geração procedural sem downloads; adapte o diretório de saída para o projeto. Só execute se Node.js e FFmpeg estiverem disponíveis.
- Criar um único componente enorme em vez de peças reutilizáveis que seguem o tema.
- Incompatibilidade entre `durationInFrames` da composição e o conteúdo da cena (tempo morto).
- Esquecer `--overwrite` nas novas renderizações e inspecionar um arquivo antigo.
- Fontes: nunca use as fontes padrão do sistema nos textos principais; carregue uma fonte de exibição com `@remotion/google-fonts` ou `@font-face` + `staticFile`.
- Tentar apenas “descrever” o resultado para a pessoa em vez de renderizá-lo e verificá-lo.

# Padrões de movimento — biblioteca de componentes

Implementações funcionais. Importe `theme` de `src/theme.ts` do projeto.
Todos os componentes pressupõem o uso de `useCurrentFrame()` / `useVideoConfig()` do Remotion.

## Conteúdo
1. Entrada premium (o padrão principal)
2. Elementos filhos escalonados
3. Revelação de texto palavra por palavra
4. Malha de fundo (nunca use fundos chapados)
5. Sobreposição de gradação de cor
6. Granulação procedural (sem arquivo de recurso)
7. Vinheta
8. Ken Burns para imagens estáticas
9. Contador animado
10. Faísca / marca radial de logotipo
11. Saídas
12. Movimento sutil de elementos parados
13. Profundidade com paralaxe
14. Transições (biblioteca + feitas manualmente)
15. Desfoque de movimento
16. Sincronização de áudio + efeitos sonoros
17. Legendas sincronizadas palavra por palavra sobre a gravação

---

## 1. Entrada premium (fade + subida + escala)
```tsx
const Entrance: React.FC<{delay?: number; children: React.ReactNode}> =
({ delay = 0, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  return (
    <div style={{
      opacity: p,
      transform: `translateY(${interpolate(p, [0, 1], [40, 0])}px)
                  scale(${interpolate(p, [0, 1], [0.94, 1])})`,
    }}>{children}</div>
  );
};
```
Para usar uma curva Bézier em vez de `spring` (slides controlados):
```tsx
const x = interpolate(frame, [0, 25], [60, 0], {
  easing: theme.ease.out,
  extrapolateLeft: "clamp", extrapolateRight: "clamp", // SEMPRE inclua ambos
});
```

## 2. Elementos filhos escalonados
```tsx
{items.map((item, i) => <Entrance key={i} delay={start + i * 4}>{item}</Entrance>)}
```
Use intervalos de 3–6 quadros. Palavras: 3. Cards/itens de lista: 4–5. Blocos grandes: 6.

## 3. Revelação de texto palavra por palavra
```tsx
const WordReveal: React.FC<{text: string; delay?: number; per?: number;
  style?: React.CSSProperties}> = ({ text, delay = 0, per = 3, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "0.26em", ...style }}>
      {text.split(" ").map((word, i) => {
        const p = spring({ frame: frame - delay - i * per, fps,
          config: theme.spring.snappy });
        return (
          <span key={i} style={{
            display: "inline-block", opacity: p,
            transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px)`,
          }}>{word}</span>
        );
      })}
    </div>
  );
};
```
**Atenção:** ao colocar dois blocos grandes de texto lado a lado em uma linha flex, use um `gap` em pixels (por exemplo, `gap: 42`), NÃO em `em`. A unidade `em` é calculada com base no tamanho da fonte do elemento pai (geralmente 16 px), criando espaços quase nulos ao lado de textos de 150 px.

## 4. Malha de fundo
```tsx
const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50, d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div style={{ position: "absolute", width: 1200, height: 1200,
        borderRadius: "50%", top: -450, left: -300 + d1, filter: "blur(50px)",
        background: `radial-gradient(circle, ${theme.colors.primary}33, transparent 62%)` }}/>
      <div style={{ position: "absolute", width: 900, height: 900,
        borderRadius: "50%", bottom: -400, right: -250 - d2, filter: "blur(70px)",
        background: `radial-gradient(circle, ${theme.colors.accent}22, transparent 65%)` }}/>
    </AbsoluteFill>
  );
};
```

## 5. Sobreposição de gradação de cor (renderizada ACIMA de todo o conteúdo, abaixo da granulação)
Unifica recursos incompatíveis (imagens estáticas geradas por IA, B-roll e capturas de tela) em um único visual.
```tsx
const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary,
      mixBlendMode: "soft-light", opacity: 0.18 }}/>
    <AbsoluteFill style={{ background:
      "linear-gradient(180deg, rgba(0,0,0,0.10), transparent 28%, transparent 72%, rgba(0,0,0,0.2))" }}/>
  </AbsoluteFill>
);
```
Opacidade de 0.10–0.15 para temas claros; 0.18–0.25 para temas escuros. Correção por recurso quando um clipe ainda destoa: `filter: "saturate(1.1) contrast(1.08)"`.

## 6. Granulação procedural — sem arquivos de recurso
```tsx
const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none",
    backgroundImage: noise, backgroundSize: "220px",
    backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, // cintilação de filme
    opacity: 0.05, mixBlendMode: "multiply" }}/>; // use "overlay" em temas escuros
};
```

## 7. Vinheta (camada mais alta)
```tsx
const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background:
    "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.22) 100%)" }}/>
);
```

## 8. Ken Burns — para toda imagem estática, sem exceções
```tsx
const KenBurns: React.FC<{src: string; zoomTo?: number}> = ({ src, zoomTo = 1.1 }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const scale = interpolate(frame, [0, durationInFrames], [1, zoomTo],
    { easing: theme.ease.inOut });
  const pan = interpolate(frame, [0, durationInFrames], [0, -25]);
  return <Img src={staticFile(src)} style={{ width: "100%", height: "100%",
    objectFit: "cover", transform: `scale(${scale}) translateX(${pan}px)` }}/>;
};
```
Alterne zoom-in/zoom-out entre tomadas consecutivas. Máscara em cards arredondados:
`borderRadius: 32, overflow: "hidden", border: "1px solid rgba(255,255,255,0.08)",
boxShadow: "0 40px 80px -20px rgba(0,0,0,0.6)"`.

## 9. Contador animado
```tsx
const value = interpolate(
  spring({ frame: frame - delay, fps, config: { damping: 30, stiffness: 60 } }),
  [0, 1], [0, target]);
<span style={{ fontVariantNumeric: "tabular-nums" }}>{value.toFixed(1)}%</span>
```
`tabular-nums` impede que o layout pule enquanto os dígitos mudam.

## 10. Faísca / marca radial de logotipo (raios escalonados)
```tsx
const rays = 12;
{Array.from({ length: rays }).map((_, i) => {
  const p = spring({ frame: frame - delay - i * 1.2, fps,
    config: theme.spring.snappy });
  return <div key={i} style={{ position: "absolute", left: "50%", top: "50%",
    width: size * 0.085, height: size * 0.46 * p, background: theme.colors.primary,
    borderRadius: size, transformOrigin: "50% 0%",
    transform: `translateX(-50%) rotate(${(360 / rays) * i}deg) translateY(${size * 0.07}px)` }}/>;
})}
```
Envolva em um container com escala elástica usando `spring` e rotação suave usando `spring` de -120°, e aplique `filter: drop-shadow(0 0 ${size*0.25}px ${theme.colors.glow})`.

## 11. Saídas — mais rápidas que as entradas
```tsx
const exitY = interpolate(frame, [durationInFrames - 12, durationInFrames - 2],
  [0, -42], { easing: theme.ease.in,
  extrapolateLeft: "clamp", extrapolateRight: "clamp" });
const exitO = interpolate(frame, [durationInFrames - 12, durationInFrames - 2],
  [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
```
Aplique a todo elemento visível ou a um container da cena.

## 12. Movimento sutil de elementos parados (elementos na tela por mais de 2 s)
```tsx
const breathe = 1 + Math.sin(frame / 22) * 0.015;          // escala
const float = Math.sin(frame / 30) * 3;                     // translateY em px
const drift = interpolate(frame, [0, 300], [0, -20]);       // paralaxe lenta
```

## 13. Paralaxe (3 camadas, profundidade instantânea)
```tsx
const x = interpolate(frame, [0, 90], [0, -120], { easing: theme.ease.inOut });
<Bg style={{ transform: `translateX(${x * 0.3}px)` }}/>
<Mid style={{ transform: `translateX(${x * 0.6}px)` }}/>
<Fg style={{ transform: `translateX(${x}px)` }}/>
```

## 14. Transições
Biblioteca (`npm i @remotion/transitions`):
```tsx
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { slide } from "@remotion/transitions/slide";
<TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={90}><A/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={slide({ direction: "from-right" })}
    timing={linearTiming({ durationInFrames: 12 })}/>
  <TransitionSeries.Sequence durationInFrames={150}><B/></TransitionSeries.Sequence>
</TransitionSeries>
```
Feitas manualmente, cada uma com 8–14 quadros:
- **Whip pan**: o fundo se desloca 1500 px em 6 quadros com `filter: blur(8px)` durante o movimento; esconda o corte no meio do deslocamento.
- **Passagem por escala**: A aumenta até 1.3 e desaparece; B aumenta de 0.8 a 1 por baixo.
- **Revelação por máscara**: uma forma na cor da marca atravessa a tela; esconda o corte atrás dela.

## 15. Desfoque de movimento (qualquer elemento que se mova mais de 30 px/quadro)
```tsx
import { Trail } from "@remotion/motion-blur";
<Trail layers={4} lagInFrames={0.4}><FastThing/></Trail>
```

## 16. Sincronização de áudio + efeitos sonoros
```tsx
import { Audio, Sequence, staticFile } from "remotion";
<Audio src={staticFile("sfx/music.mp3")} volume={0.25}/>
<Sequence from={entranceFrame - 3}> {/* EFEITO SONORO 2–3 quadros ANTES da entrada do visual */}
  <Audio src={staticFile("sfx/whoosh.mp3")} volume={0.7}/>
</Sequence>
```
Faça o corte na batida da música: `framesPerBeat = fps * 60 / BPM`. Posicione os cortes de cena e impactos em múltiplos desse valor. Música de fundo a -18 dB sob efeitos sonoros/narração.

## 17. Legendas sincronizadas palavra por palavra sobre a gravação
Para gravações com fala: obtenha as marcações de tempo de cada palavra (Whisper ou `@remotion/install-whisper-cpp`) e, em seguida, mapeie cada grupo de legendas para um `<Sequence>` usando `@remotion/captions`:
```tsx
import { createTikTokStyleCaptions } from "@remotion/captions";
const { pages } = createTikTokStyleCaptions({ captions, combineTokensWithinMilliseconds: 1200 });
// Renderize cada página em uma Sequence a partir de msToFrame(page.startMs),
// destaque o token ativo comparando currentTime às marcações de tempo dos tokens
```
Estilo: fonte de exibição pesada, 2–4 palavras por página, palavra ativa em `theme.colors.primary`, posicionada a cerca de 65% da altura (dentro da zona segura 9:16).
# Regras de design — cor, tipografia, ritmo, som e lista de conferência

## Sistema de cores
Use uma base escura (ou clara) + UMA cor principal + uma cor de destaque + cores neutras. Proporção 60/30/10: 60% base, 30% superfícies secundárias, 10% cor principal. A cor principal aparece em NO MÁXIMO um elemento por quadro: ela direciona o olhar.

Paletas comprovadas (adapte à marca da pessoa, se houver):
- Tecnologia escura: base #0A0A0F, principal #7C3AED, destaque #22D3EE, texto #F4F4F5
- Editorial acolhedora (inspirada na Claude): base #FAF7F2, principal #D97757, tinta #1F1E1B
- Premium acolhedora: base #1A120B, principal #E8A33D, destaque #F4E9DA
- Clara e limpa: base #F7F5F2, tinta #1A1A1A + uma cor de destaque saturada

Aplique brilho somente ao elemento da cor principal:
`boxShadow: 0 0 60px ${hero}66, 0 0 120px ${hero}33` (no texto: `textShadow`). Mais de um elemento brilhando por quadro parece Las Vegas. Não faça isso.

## Tipografia
- Texto principal: fonte de exibição (Clash Display, Cabinet Grotesk, General Sans, Satoshi — gratuitas no Fontshare; ou uma fonte variável do Google via @remotion/google-fonts). Peso de 600 a 800, `letterSpacing: -0.03em`, `lineHeight: 1.05`.
- Tamanho principal em Reels: 80–140 px em um vídeo de 1080 px de largura. Paisagem: 100–160 px em 1920 px.
- Texto auxiliar/legendas: fonte sem serifa limpa (Inter/sistema), peso de 400 a 500, cor atenuada.
- Destaque UMA palavra por título: cor principal, sublinhado animado ou um elemento em formato de cápsula que escala atrás da palavra 5 quadros depois que ela aparece.
- Números: contadores animados com `tabular-nums` (consulte o padrão 9 em motion-patterns).

## Arquitetura da cena
Estrutura para Reel de 30 s:
```text
0.0–1.5s  GANCHO      visual mais marcante + afirmação. Movimento nos PRIMEIROS 15 quadros.
1.5–3.0s  CONTEXTO    uma linha, um visual, ainda em movimento.
3–22s     CONTEÚDO    3–4 batidas. Cada batida: IMPACTO -> pausa (15–20 quadros estáticos) -> construção.
22–27s    RECOMPENSA  resultado/número/demonstração. Maior animação do vídeo.
27–30s    CTA         uma ação, calma, brilho na palavra do CTA.
```
- Inclua um novo elemento visual pelo menos a cada 90 quadros.
- Pausas são um recurso de design: movimento rápido → imobilidade completa → próximo movimento. Movimento constante parece amador; contraste transmite sofisticação.
- Zona segura 9:16: mantenha o texto essencial nos cerca de 75% centrais da altura (a interface da plataforma cobre a parte superior e inferior).
- Vinheta de logotipo de 5 s: símbolo (0–0,8 s) → logotipo por extenso (0,6–1,8 s) → detalhe/slogan (2–3,5 s) → respiro → saída (últimos 0,5 s).

## Design de som (50% da qualidade percebida — nunca entregue sem áudio, a menos que peçam)
- Cada entrada de impacto: whoosh ou click curto começando 2–3 quadros ANTES de o visual aparecer (adiantar parece sincronizado; atrasar parece quebrado).
- Transições: crescendo antes do corte, impacto de grave NO corte.
- Contadores: loop suave de tique-taque durante a contagem.
- Música de fundo em volume baixo (cerca de 0,2–0,3), reduzido ainda mais sob a narração.
- Sempre que possível, escolha a música PRIMEIRO; calcule `framesPerBeat = fps*60/BPM` e alinhe os cortes às batidas.
- Fontes gratuitas de efeitos sonoros para sugerir: Pixabay, Mixkit, freesound.org. Um kit de 10 arquivos cobre tudo: 2 whooshes, 2 clicks, crescendo, impacto de grave, brilho, tique, pop e whoosh reverso.

## Orientação para gerar recursos (quando a pessoa gerar imagens para o vídeo)
Mantenha a estrutura do prompt fixa, varie apenas o tema e use palavras idênticas para luz e paleta em toda a série. Gere já na proporção final:
```text
[tema], fotografia cinematográfica de produto, estúdio escuro e atmosférico, luz de contorno [cor principal], sombras profundas, pouca profundidade de campo, 9:16
```

## Configurações de renderização
- Masters para upload: `--codec h264 --crf 16` (as plataformas recomprimem; deixe margem de qualidade).
- Pilhas pesadas de transparência/desfoque: adicione `--image-format png`.
- Confira movimentos suspeitos a 0,25x no Remotion Studio: falhas de easing invisíveis em velocidade normal ficam óbvias em um quarto da velocidade.

## LISTA DE CONFERÊNCIA PRÉ-ENTREGA — siga para todo vídeo antes de apresentá-lo
- [ ] Nenhum easing linear; todas as interpolações com limites `clamp`.
- [ ] Entradas animam de 2 a 3 propriedades e são escalonadas; nada entra simultaneamente.
- [ ] Saídas animadas e mais rápidas que as entradas.
- [ ] Toda imagem estática tem Ken Burns; movimentos rápidos têm desfoque de movimento.
- [ ] Pilha de 5 camadas presente (malha de fundo, recursos, gráficos, gradação, granulação + vinheta).
- [ ] Uma cor principal; no máximo um elemento com essa cor ou brilho por quadro.
- [ ] Fonte de exibição com peso ≥600 nos elementos principais; não use fonte padrão do sistema nesses textos.
- [ ] Espaçamentos em px (não em) entre blocos de texto grandes.
- [ ] Há pausas: pelo menos 3 momentos de imobilidade.
- [ ] Efeitos sonoros nos impactos principais e cortes no ritmo (se houver áudio).
- [ ] Texto dentro da zona segura; nada encostando nas bordas do quadro.
- [ ] Renderizado; quadros extraídos com ffmpeg, inspecionados visualmente, problemas corrigidos, renderizado outra vez e inspecionado novamente.
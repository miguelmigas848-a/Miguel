// theme.ts — fonte única da verdade para todo projeto Remotion.
// NUNCA coloque cores, easings ou configurações de spring diretamente nos componentes.
import { Easing } from "remotion";

export const theme = {
  colors: {
    // Adapte à marca da pessoa. Padrão: tecnologia escura.
    bg: "#0A0A0F",
    bgAlt: "#12121A",
    primary: "#7C3AED", // A cor principal — no máximo um elemento por quadro
    accent: "#22D3EE",
    text: "#F4F4F5",
    textDim: "#A1A1AA",
    glow: "rgba(124, 58, 237, 0.4)",
  },
  fonts: {
    display: "Clash Display", // carregue via @font-face + staticFile ou google-fonts
    body: "Inter",
    mono: "JetBrains Mono",
  },
  // Curvas de easing. Linear é proibido.
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // easeOutExpo — entradas
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // easeInOutQuint — movimentos, Ken Burns
    in: Easing.bezier(0.7, 0, 0.84, 0), // somente saídas
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 }, // impactos de UI, palavras
    smooth: { damping: 20, stiffness: 90, mass: 1 }, // elementos grandes
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 }, // detalhes divertidos, logotipos
  },
} as const;
# Fontes e preservação do fluxo Reel

O fluxo Reel foi incorporado a partir do pacote `reel-skill-ptbr.zip`. As cópias recebidas de `skill-reel-main` foram usadas para comparar os recursos e identificar conteúdo repetido; arquivos de apoio equivalentes aparecem uma única vez para não desperdiçar o limite do pacote.

Os modelos, scripts, exemplos, imagens, áudios, fontes, configurações e referências de edição estão nas pastas `corte/`, `modelo/`, `ferramentas/` e `anexos/`. O ponto de entrada do pacote original foi integrado ao `SKILL.md` principal; o fluxo detalhado está em `FLUXO-REEL.md`.

Os pacotes ZIP originais não foram colocados dentro desta skill, pois os carregadores rejeitam arquivos ZIP aninhados. Eles permanecem intactos na pasta de origem. Identificadores de código, comandos, variáveis, formatos e nomes de ferramentas permanecem na forma técnica canônica para preservar a execução.

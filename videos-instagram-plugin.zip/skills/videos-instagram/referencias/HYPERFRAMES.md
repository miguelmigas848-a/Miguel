# HyperFrames para vídeos verticais

Use este fluxo somente se o projeto já estiver em HyperFrames ou se a pessoa pedir explicitamente essa tecnologia. A skill segue o formato Agent Skills; os manifestos de plugin do pacote original não são necessários aqui.

## Antes de editar

1. Confirme que o projeto existe e que `npx hyperframes` está acessível. A documentação recebida indica Node.js 22+ e FFmpeg; confira os requisitos e comandos da versão instalada.
2. Consulte `npx hyperframes --help` e `npx hyperframes <comando> --help` antes de usar comandos cuja sintaxe dependa da versão.
3. Em projeto novo, use `npx hyperframes init <diretório>` somente quando a CLI estiver instalada e o ambiente permitir executar comandos.
4. Em projeto existente, inspecione `info`, `compositions`, `timeline --json` e a documentação do CLI. Preserve as alterações já feitas pela pessoa.

## Contrato de composição

- Mantenha uma composição raiz e cenas editáveis em HTML; guarde mídia e fontes em `assets/` e use caminhos relativos, sem iniciar caminhos com `/`.
- Elementos temporizados usam `class="clip"`, `data-start` e `data-duration` em segundos; o `data-duration` raiz define o comprimento do vídeo.
- Toda animação deve depender do tempo pausado da timeline. Evite relógio do sistema, aleatoriedade não reproduzível, timers, buscas de rede durante a renderização e animações infinitas.
- Mantenha texto, cores e mídia substituível como variáveis de composição. Não transforme elementos editáveis em imagens achatadas sem necessidade.
- No formato vertical, mantenha rosto, legendas e informação essencial longe das áreas que a interface pode cobrir. Confirme as zonas seguras atuais para o destino solicitado.

## Mídia e montagem

- Coloque imagens, vídeos, narração, música e efeitos em arquivos locais do projeto; registre origem e licença quando usar mídia externa.
- Use material oficial para logotipos e telas reais. Não invente interfaces, dados ou marcas.
- Antes de criar manualmente um efeito nomeado, pesquise o catálogo local do HyperFrames se o comando estiver disponível. Instale um bloco somente se ele atender ao pedido e mantenha-o editável.
- Para Remotion, classifique cada parte: converta para HTML/GSAP quando o resultado puder continuar editável; mantenha código que precise renderizar cada quadro em um adaptador hospedado; use vídeo/imagem quando só o resultado final puder ser reutilizado. Compare os quadros com a origem quando fidelidade for importante.
- Trate voz, avatar, remoção de fundo e provedores externos como recursos opcionais. Confirme antes qualquer serviço pago ou consumo de créditos.

## Verificação e entrega

1. Após a primeira montagem e depois de alterações estruturais, rode `npx hyperframes lint` se disponível.
2. Use `npx hyperframes check --json`; leia os resultados, corrija erros e não interprete “0 amostras” como uma aprovação visual.
3. Gere snapshots no meio de cada cena, nos cortes, transições e momentos de texto. Abra os PNGs e inspecione-os; uma checagem de código sozinha não verifica o vídeo.
4. Gere a prévia e revise-a antes da renderização final quando o pedido permitir essa etapa.
5. Renderize com a qualidade aceita pela versão instalada. Confirme que o MP4 não está vazio e que sua duração corresponde à composição; inspecione novamente os quadros renderizados.
6. Não publique nem envie o vídeo sem solicitação explícita.

Os comandos e nomes de opções do HyperFrames podem evoluir. Se a CLI local contradisser este resumo, siga a ajuda e a documentação da versão instalada e explique qualquer diferença relevante.
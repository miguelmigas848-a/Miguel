# Revisão criativa para Reels

Use esta rubrica quando for útil comparar opções de gancho, roteiro, ritmo, legenda ou direção visual. Não rode um torneio multiagente automaticamente.

## Processo enxuto

1. Gere até três propostas com enfoques diferentes; mantenha todas fiéis ao material e aos fatos.
2. Revise cada proposta com os mesmos critérios e notas de 1 a 5.
3. Registre um ponto forte, um risco e uma alteração concreta por proposta.
4. Escolha a maior nota ponderada. Se houver empate, prefira a versão mais clara, verificável e fácil de assistir sem som.
5. Mostre as diferenças e a justificativa. Não apresente a avaliação como se tivesse usado subagentes quando foi feita em uma única sessão.

| Critério | Peso |
| --- | ---: |
| Gancho imediato e relevante para o público | 20 |
| Fidelidade aos fatos e à fala original | 20 |
| Clareza da ideia principal e da chamada para ação | 15 |
| Ritmo dos cortes e variedade visual | 15 |
| Leitura das legendas, contraste e zona segura | 15 |
| Qualidade de áudio e sincronização | 10 |
| Originalidade sem imitar marcas ou inventar telas | 5 |

**Falha eliminatória:** afirmação inventada, palavra cortada, legenda que contradiz o áudio, rosto/elemento essencial encoberto ou uso de material sem origem clara. Uma nota alta não compensa uma falha eliminatória.

## Memória de marca

Se a pessoa pedir para seguir preferências anteriores, consulte apenas a ferramenta de memória realmente conectada ao ambiente. Pesquise primeiro o índice e depois leia os registros relevantes; cite datas, projetos ou IDs quando existirem. Sem conexão, solicite as referências necessárias ou continue com as informações desta conversa. Não afirme que consultou ou salvou memória sem evidência da ferramenta.

## Arena opcional

Os arquivos `fontes/arena/` preservam o auxiliar Arena recebido. Ele só pode ser considerado quando a pessoa pedir uma disputa, o ambiente oferecer delegação real e ela aceitar o custo e o volume de chamadas. Não invoque o plugin, não simule subagentes e não execute centenas de chamadas por padrão. Para tarefas comuns, use a revisão enxuta acima.
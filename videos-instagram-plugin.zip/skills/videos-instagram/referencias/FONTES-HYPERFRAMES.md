# Referências e links do HyperFrames

O guia de produção usa somente a integração HyperFrames descrita nas referências desta pasta. O repositório original excede os limites de uma skill de upload e não foi embutido; os links recebidos permanecem disponíveis aqui.

- Repositório: https://github.com/heygen-com/hyperframes
- Pacote npm: https://www.npmjs.com/package/hyperframes
- Site: https://hyperframes.studio/
- Aplicativo Studio: https://hyperframes.studio/studio
- Início rápido: https://hyperframes.heygen.com/quickstart
- Introdução/documentação: https://hyperframes.heygen.com/introduction
- Catálogo de blocos: https://hyperframes.heygen.com/catalog/blocks/data-chart
- Galeria: https://hyperframes.heygen.com/showcase
- Comunidade: https://discord.gg/EbK98HBPdk
- Node.js: https://nodejs.org
- Manifesto de plugins usado no pacote de origem: https://agent-plugins.org/schemas/1.0.0/plugin.schema.json
- Imagem de apresentação do README original: https://github.com/user-attachments/assets/f6ff9fae-f33d-4f68-bd54-f3ed4ba6473b
- Selo de licença do README: https://img.shields.io/badge/license-Apache%202.0-blue.svg
- Selo de versão do npm: https://img.shields.io/npm/v/hyperframes.svg?style=flat
- Selo de downloads npm: https://img.shields.io/npm/dm/hyperframes.svg?style=flat
- Selo Node do README: https://img.shields.io/badge/node-%3E%3D22-brightgreen
- Selo Discord do README: https://img.shields.io/badge/Discord-Join-5865F2?logo=discord&logoColor=white
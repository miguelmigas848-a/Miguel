# Guia detalhado da Arena

O arquivo de origem correspondente continha somente metadados. Para consultar as instruções completas e os modelos de briefing, leia [`skills/arena/ARENA-GUIA-DETALHADO.md`](skills/arena/ARENA-GUIA-DETALHADO.md).

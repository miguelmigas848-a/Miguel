> Referência do plugin Arena de origem. As instruções de instalação abaixo pertencem ao plugin separado e não se aplicam a esta skill unificada; use o `README.md` e o `SKILL.md` na raiz deste ZIP.

# Habilidade Arena

Quando uma resposta não atende ao que você precisa, compare várias soluções concorrentes numa disputa. A Arena distribui a mesma tarefa a N subagentes, cada um com um cartão de estratégia diferente (modo de raciocínio, fluxo de trabalho e estratégia), e organiza uma chave eliminatória. Os concorrentes criticam as soluções adversárias, defendem e revisam as próprias, e um juiz avalia cada confronto com base numa rubrica escrita.

O resultado é a solução que sobreviveu, as críticas que ela superou e o número de rodadas.

**A habilidade não altera os arquivos do projeto.** Os subagentes gravam seus resultados dentro de .arena/. A solução vencedora é apresentada para você decidir o que fazer.

## Instalação

Peça ao Claude para instalar a habilidade a partir deste repositório:

~~~
https://github.com/Jakeschincariol/arena-skill

Instale esta habilidade e confirme que /arena funciona.
~~~

Ou copie a pasta manualmente no Claude Code:

~~~bash
git clone https://github.com/Jakeschincariol/arena-skill.git
cp -r arena-skill/skills/arena ~/.claude/skills/
~~~

Ou instale como plugin:

~~~text
/plugin marketplace add Jakeschincariol/arena-skill
/plugin install arena-skill@arena-skill
~~~

O Claude Code inclui o nome do plugin no comando. Instalado como plugin, o comando fica /arena-skill:arena. Copie a pasta se quiser usar /arena sem o prefixo. Para instalar apenas no projeto, copie a pasta para .claude/skills/ no repositório.

No ChatGPT, use Plugins > Habilidades > Criar > Carregar do computador e selecione o ZIP distribuído com esta habilidade. A disponibilidade do carregamento depende do produto, da conta e das permissões do espaço de trabalho.

O formato Agent Skills é compartilhado entre plataformas que o implementam. A execução completa da Arena também precisa de Python 3.8 ou superior, acesso aos arquivos auxiliares e uma ferramenta de delegação de subagentes. O Claude Code fornece a ferramenta Agent. No ChatGPT ou em Claude.ai, a execução multiagente depende das ferramentas disponíveis nessa superfície. Se não houver ferramenta de delegação, a habilidade informa a limitação e pode fazer uma revisão sequencial menor; ela não apresenta essa revisão como torneio multiagente.

## Uso

~~~text
/arena
/arena --quick escreva o título da nossa página de preços
/arena --agents 32 corrija o teste instável em tests/test_api.py
/arena --seed 7 planeje minha semana de lançamento, tenho 6 horas por dia
~~~

Quando usado sem argumentos, /arena considera a solicitação mais recente como tarefa e a resposta que você não gostou como referência a superar. A habilidade também pode ser acionada quando você diz algo como “essa resposta está ruim; coloque as opções em disputa”. Nesse caso, ela pede autorização antes de iniciar uma execução custosa.

| Opção | O que faz |
| --- | --- |
| --agents N | Número de concorrentes. O padrão é 100. |
| --quick | 16 concorrentes. É o modo recomendado para tarefas comuns. |
| --seed S | Mesmo valor de seed produz os mesmos cartões e confrontos. O padrão é aleatório e fica registrado. |
| --wave W | Número de subagentes por onda. O padrão é 10. Aumente somente se o limite da plataforma tiver sido aumentado. |

## Como funciona

1. **Criação.** N subagentes, uma chamada Agent para cada um. Todos recebem a mesma tarefa, byte a byte (há um teste que confere isso), além de um cartão de estratégia. Há 15 modos de raciocínio, 12 fluxos de trabalho e 12 estratégias, resultando em 2.160 cartões diferentes. O distribuidor entrega um cartão exclusivo para cada agente, sem repetições.
2. **Crítica.** As soluções são pareadas, evitando colocar dois agentes com o mesmo modo de raciocínio um contra o outro sempre que possível. Cada lado critica a solução adversária com base em seu cartão: o que está errado, quais requisitos foram ignorados e que entrada exata causa uma falha. São permitidas até 7 críticas, classificadas como FATAL, MAJOR ou MINOR.
3. **Defesa.** Cada lado responde a todas as críticas recebidas, concedendo ou rebatendo com evidências, e revisa a própria solução para corrigir o que concedeu.
4. **Julgamento.** Um subagente juiz independente lê as duas soluções revisadas, confere cada crítica e atribui notas segundo a [rubrica](skills/arena/rubric.md): correção 30, completude em relação à tarefa 25, robustez diante das críticas 20, especificidade 15 e clareza 10. O juiz não vê os cartões. bracket.py calcula a pontuação ponderada. A solução com a maior nota avança; uma solução com falha fatal verificada não pode vencer uma sem falha fatal.
5. **Repetição.** As soluções sobreviventes seguem para a rodada seguinte. Se houver um número ímpar, uma delas passa sem confronto; a mesma pessoa não recebe essa vantagem duas vezes enquanto outra ainda não a tiver recebido.
6. **Resultado.** Resta uma solução. Você recebe a solução, as críticas que ela superou, seu cartão e o total de rodadas. Se havia uma resposta rejeitada, um juiz final a compara às cegas com a campeã e informa as duas notas, mesmo quando a resposta antiga vence.

A chave para 100 agentes pode ser consultada com python3 skills/arena/bracket.py plan:

~~~
  rodada  vivos  confrontos  folga  chamadas a subagentes  ondas
  criação    100       -       -             100            10
       1    100      50       -             250            25
       2     50      25       -             125            13
       3     25      12      sim              60             8
       4     13       6      sim              30             5
       5      7       3      sim              15             3
       6      4       2       -               10             3
       7      2       1       -                5             3
  total                                595             70

  participantes por rodada: 100 -> 50 -> 25 -> 13 -> 7 -> 4 -> 2 -> 1
~~~

O torneio inteiro fica em um arquivo JSON, administrado por bracket.py. A sessão principal conduz as etapas sem ler centenas de arquivos de solução: cada subagente grava seu trabalho no disco e responde com uma linha. Se o contexto da conversa for resumido durante a execução, bracket.py next retoma o processo a partir do estado salvo.

## Custo

A habilidade é gratuita. O consumo de tokens fica por sua conta; 100 agentes podem consumir muitos tokens.

| Agentes | Rodadas | Chamadas a subagentes | Ondas de 10 |
| ---: | ---: | ---: | ---: |
| 100 (padrão) | 7 | 595 | 70 |
| 64 | 6 | 379 | 49 |
| 32 | 5 | 187 | 28 |
| 16 (--quick) | 4 | 91 | 16 |
| 8 | 3 | 43 | 10 |

Acrescente uma chamada se houver uma resposta rejeitada para comparar. Cada chamada lê a tarefa e uma ou duas soluções, então o custo cresce com o tamanho da tarefa. Use --quick ou --agents 16 em tarefas comuns; reserve a arena completa para respostas importantes. Antes de começar, a habilidade informa esses números. Você também pode consultá-los com python3 skills/arena/bracket.py plan --agents N.

## O script

bracket.py usa apenas bibliotecas padrão do Python e mantém o estado do torneio. No Windows, use python; no macOS e no Linux, use python3 nos comandos abaixo.

~~~bash
python3 skills/arena/bracket.py plan --agents 100        # rodadas, chamadas e ondas; não grava arquivos
python3 skills/arena/bracket.py init --agents 100 --seed 7 --task-file task.md [--baseline-file antiga.md]
python3 skills/arena/bracket.py next                     # próxima ação e comando exato
python3 skills/arena/bracket.py prompts attack           # cria briefings e lista as tarefas por onda
python3 skills/arena/bracket.py pairings                 # confrontos da rodada, incluindo folga
python3 skills/arena/bracket.py collect                  # registra os vereditos dos juízes
python3 skills/arena/bracket.py record r3-m07 a042 --reason "..."   # registra um resultado manualmente
python3 skills/arena/bracket.py advance                  # elimina perdedores e organiza a próxima rodada
python3 skills/arena/bracket.py status                   # mostra quem continua e quem foi eliminado
python3 skills/arena/bracket.py winner                   # mostra a solução sobrevivente, as críticas superadas e as rodadas
~~~

A suíte de testes conduz uma arena de 100 agentes pela linha de comando, com vencedores aleatórios, e verifica que ela termina com exatamente um sobrevivente. Também confere execuções com 16, 7 e 1 agente, as garantias do distribuidor e cada etapa desde a criação até a avaliação final, usando agentes simulados:

~~~bash
python3 -m unittest discover -s tests -v
~~~

## Observações importantes

**“100 versões de Claude” significa 100 subagentes do modelo em uso**, não 100 modelos diferentes. Os cartões de estratégia criam as diferenças. O distribuidor garante cartões únicos, distribui cada modo de raciocínio, fluxo de trabalho e estratégia de forma equilibrada e, até 144 agentes, evita que dois concorrentes compartilhem dois dos três elementos.

**Um concorrente é seu cartão e seu arquivo de solução.** Os subagentes não mantêm memória entre chamadas. Assim, quando o concorrente a017 critica alguém na rodada 3, ele é um subagente novo que recebe o cartão de a017 e sua solução mais recente. São 100 concorrentes e 595 chamadas.

**“A melhor resposta” é a que venceu todos os confrontos.** Os juízes também usam o modelo disponível e avaliam com base numa rubrica escrita neste repositório. O resultado é a resposta mais forte encontrada pelo torneio, não uma prova de que ela está correta. Por isso, o relatório mostra as críticas superadas e informa claramente se a resposta rejeitada recebeu nota maior.

**Os 100 agentes não trabalham todos ao mesmo tempo.** O Claude Code executa até 10 chamadas de ferramenta simultâneas por padrão, pela configuração CLAUDE_CODE_MAX_TOOL_USE_CONCURRENCY. Por isso, a criação usa 10 ondas e o torneio completo usa 70. O processo demora. Se aumentar esse limite, ajuste --wave. Em outros ambientes, siga o limite real deles.

**Pode haver pedidos de permissão.** Cada subagente grava arquivos em .arena/. No modo de permissão padrão, cada gravação pode pedir aprovação. No Claude Code, o modo accept-edits (Shift+Tab) pode reduzir esses pedidos.

**Os subagentes não veem sua conversa.** A habilidade grava uma tarefa independente; esse arquivo é tudo o que os concorrentes sabem. Um requisito que não entrar nele pode passar despercebido por todos. O arquivo fica em .arena/<execução>/task.md.

**A habilidade não altera seu projeto.** Sugestões de código retornam como diff ou arquivos completos na solução vencedora. Aplicar as mudanças é uma decisão sua.

**A mesma seed repete os cartões e o chaveamento, não as respostas.** O modelo não é determinístico.

**A arena não corrige uma tarefa mal definida.** Uma tarefa vaga produzirá respostas vagas em estilos diferentes.

## Arquivos

~~~
SKILL.md                         ponto de entrada Agent Skills para ChatGPT e Claude
skills/arena/SKILL.md             instruções do plugin do Claude Code e modelos de briefing
skills/arena/bracket.py           máquina de estados do torneio, somente biblioteca padrão
skills/arena/strategies.json      modos de raciocínio, fluxos de trabalho e estratégias
skills/arena/rubric.md            cinco critérios de avaliação para os juízes
tests/test_bracket.py             testes da máquina de estados
~~~

## Créditos

Criado por Jake Schincariol, [opusjake.ai](https://opusjake.ai).

Repositório original: https://github.com/Jakeschincariol/arena-skill

## Licença

MIT. Você pode usar, modificar e distribuir o software conforme a licença incluída. O arquivo LICENSE original foi mantido sem alteração para preservar o texto legal de referência. A tradução explicativa está em LICENSE.pt-BR.

#!/usr/bin/env python3
"""bracket.py: máquina de estados do torneio /arena.

Todo o torneio fica em um arquivo JSON (arena.json), para que a pessoa que coordena
não perca o controle de quem continua, quem enfrentou quem e o que fazer em seguida,
mesmo que o contexto seja resumido no meio de uma execução com 100 agentes.

    python3 bracket.py plan --agents 100             # rodadas, chamadas e ondas; não grava nada
    python3 bracket.py init --agents 100 --seed 7 --task-file task.md [--baseline-file antiga.md]
    python3 bracket.py init --quick --task "..."     # 16 agentes
    python3 bracket.py next                          # próxima ação e comando correspondente
    python3 bracket.py prompts <phase>                # cria briefings e lista tarefas pendentes por onda
    python3 bracket.py check <phase>                  # mostra resultados que ainda faltam
    python3 bracket.py pairings                       # confrontos da rodada, incluindo a folga
    python3 bracket.py collect                        # registra os vereditos dos juízes
    python3 bracket.py record <match_id> <winner_id> [--reason "..."]
    python3 bracket.py advance                        # encerra a rodada, elimina perdedores e pareia sobreviventes
    python3 bracket.py status                         # ativos e eliminados por rodada
    python3 bracket.py winner                         # sobrevivente, confrontos vencidos e críticas superadas
    python3 bracket.py card <agent_id>                # cartão de estratégia de um concorrente

Etapas: spawn; depois attack, defend e judge em cada rodada; por fim final (somente
quando há uma resposta rejeitada para superar). Todo comando aceita --dir; sem ele,
usa a execução indicada em .arena/LATEST.

Python 3.8 ou superior; somente biblioteca padrão.
"""

import argparse
import json
import math
import os
import random
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SELF = os.path.abspath(__file__)
STRATEGIES_PATH = os.path.join(HERE, "strategies.json")
SKILL_PATH = os.path.join(HERE, "ARENA-GUIA-DETALHADO.md")
RUBRIC_PATH = os.path.join(HERE, "rubric.md")

DEFAULT_AGENTS = 100
QUICK_AGENTS = 16
DEFAULT_WAVE = 10          # Claude Code runs at most 10 tool calls at once by default
ROOT = ".arena"
LATEST = "LATEST"
STATE_FILE = "arena.json"
PHASES = ("spawn", "attack", "defend", "judge", "final")
TEMPLATES = ("competitor", "attacker", "defender", "judge", "final")
CALLS_PER_MATCH = 5        # 2 attacks, 2 defenses, 1 judge

# Os pesos devem corresponder à tabela em rubric.md; tests/test_bracket.py confere essa consistência.
WEIGHTS = (
    ("correctness", 30),
    ("completeness", 25),
    ("specificity", 15),
    ("robustness", 20),
    ("clarity", 10),
)


class ArenaError(Exception):
    pass


# ---------------------------------------------------------------- cartões

def load_strategies(path=STRATEGIES_PATH):
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    for key in ("reasoning", "workflows", "strategies"):
        items = data.get(key) or []
        if not items:
            raise ArenaError("strategies.json não contém entradas para '%s'" % key)
        ids = [it["id"] for it in items]
        if len(set(ids)) != len(ids):
            raise ArenaError("strategies.json contém um ID duplicado em '%s'" % key)
        for it in items:
            if not it.get("name") or not it.get("how"):
                raise ArenaError("a entrada '%s' em strategies.json precisa de name e how" % it["id"])
    return data


def combo_count(data):
    return len(data["reasoning"]) * len(data["workflows"]) * len(data["strategies"])


def _edge_colour(edges, k):
    """Properly edge-colour a bipartite (multi)graph with k colours, then balance it.

    edges are (row, col) pairs and k must be at least the largest degree. Proper
    means no two edges at the same row, or at the same col, share a colour. Every
    bipartite graph has one (Konig), found here with alternating-path swaps. Then
    de Werra's swaps even the colour classes out until each is used floor or ceil
    of len(edges) / k times.
    """
    colour = [None] * len(edges)
    at = ({}, {})

    def slot(side, node):
        return at[side].setdefault(node, {})

    def put(e, c):
        u, v = edges[e]
        colour[e] = c
        slot(0, u)[c] = e
        slot(1, v)[c] = e

    def take(e):
        u, v = edges[e]
        del slot(0, u)[colour[e]]
        del slot(1, v)[colour[e]]

    def walk(side, node, first, other):
        path, c = [], first
        while True:
            e = slot(side, node).get(c)
            if e is None or e in path:
                return path
            path.append(e)
            node = edges[e][1 - side]
            side = 1 - side
            c = other if c == first else first

    def swap(path, a, b):
        new = {e: (b if colour[e] == a else a) for e in path}
        for e in path:
            take(e)
        for e in path:
            put(e, new[e])

    for e, (u, v) in enumerate(edges):
        free_u = [c for c in range(k) if c not in slot(0, u)]
        free_v = set(c for c in range(k) if c not in slot(1, v))
        c = next((c for c in free_u if c in free_v), None)
        if c is None:
            a, b = free_u[0], min(free_v)
            swap(walk(1, v, a, b), a, b)
            c = a
        put(e, c)

    while True:
        count = [0] * k
        for c in colour:
            count[c] += 1
        hi = max(range(k), key=lambda c: (count[c], -c))
        lo = min(range(k), key=lambda c: (count[c], c))
        if count[hi] - count[lo] <= 1:
            return colour
        swapped = False
        for side in (0, 1):
            for node in sorted(at[side]):
                s = at[side][node]
                if hi in s and lo not in s:
                    path = walk(side, node, hi, lo)
                    if sum(colour[e] == hi for e in path) > sum(colour[e] == lo for e in path):
                        swap(path, hi, lo)
                        swapped = True
                        break
            if swapped:
                break
        if not swapped:
            raise ArenaError("não foi possível distribuir os cartões de estratégia de forma equilibrada")


def deal(n, seed, data):
    """Deal n distinct (reasoning, workflow, strategy) index triples, one per agent.

    Deterministic for a given seed and strategies.json. Guarantees:
      - no card is dealt twice
      - every reasoning mode, workflow and strategy is dealt as evenly as possible
        (any two counts differ by at most 1), so 100 agents use all of them
      - while every reasoning mode and every workflow has no more agents than there
        are strategies (up to 144 agents with the shipped cards): no two agents share
        a reasoning mode and a workflow, a reasoning mode and a strategy, or a
        workflow and a strategy. Any two agents differ in at least two of the three.

    How: agent slot i gets reasoning i mod R and workflow (i + i // lcm(R, W)) mod W,
    which never repeats a workflow inside a reasoning mode and stays balanced. The
    strategies are then a balanced proper edge colouring of that reasoning x
    workflow grid. The seed shuffles every list's labels and who gets which card.
    """
    R, W, S = len(data["reasoning"]), len(data["workflows"]), len(data["strategies"])
    total = R * W * S
    if n < 1 or n > total:
        raise ArenaError("é possível distribuir de 1 a %d cartões, não %d" % (total, n))
    rng = random.Random("arena-deal:%s" % seed)
    pr, pw, ps = list(range(R)), list(range(W)), list(range(S))
    rng.shuffle(pr)
    rng.shuffle(pw)
    rng.shuffle(ps)
    lcm = R * W // math.gcd(R, W)
    cells = [(i % R, (i + i // lcm) % W) for i in range(n)]
    deg_r = max(sum(1 for r, _ in cells if r == x) for x in range(R))
    deg_w = max(sum(1 for _, w in cells if w == x) for x in range(W))
    if deg_r <= S and deg_w <= S:
        order = list(range(n))
        rng.shuffle(order)
        colours = _edge_colour([cells[i] for i in order], S)
        strategy_of = {order[j]: colours[j] for j in range(n)}
        triples = [(r, w, strategy_of[i]) for i, (r, w) in enumerate(cells)]
    else:
        # Acima desse limite, algum par repetido é inevitável. Mantenha o equilíbrio e nunca repita um cartão.
        count, pairs_rs, pairs_ws, used, triples = [0] * S, {}, {}, set(), []
        for r, w in cells:
            low = min(count)
            s = min((c for c in range(S) if (r, w, c) not in used),
                    key=lambda c: (count[c] - low, pairs_rs.get((r, c), 0), pairs_ws.get((w, c), 0), c))
            used.add((r, w, s))
            count[s] += 1
            pairs_rs[(r, s)] = pairs_rs.get((r, s), 0) + 1
            pairs_ws[(w, s)] = pairs_ws.get((w, s), 0) + 1
            triples.append((r, w, s))
    dealt = [(pr[r], pw[w], ps[s]) for r, w, s in triples]
    rng.shuffle(dealt)
    return dealt


def agent_ids(n):
    width = max(3, len(str(n)))
    return ["a%0*d" % (width, i) for i in range(1, n + 1)]


def bracket_sizes(n):
    """Quantidade de concorrentes no início de cada rodada, até restar 1. 100 -> 50 -> 25 -> 13 -> 7 -> 4 -> 2 -> 1."""
    sizes = [n]
    while sizes[-1] > 1:
        sizes.append((sizes[-1] + 1) // 2)
    return sizes


# ---------------------------------------------------------------- caminhos

def spawn_out(d, aid):
    return os.path.join(d, "r0", aid + ".md")


def attack_out(d, rnd, mid, attacker):
    return os.path.join(d, "r%d" % rnd, "%s.%s.attack.md" % (mid, attacker))


def defense_out(d, rnd, mid, aid):
    return os.path.join(d, "r%d" % rnd, "%s.%s.defense.md" % (mid, aid))


def revised_out(d, rnd, mid, aid):
    return os.path.join(d, "r%d" % rnd, "%s.%s.solution.md" % (mid, aid))


def verdict_out(d, rnd, mid):
    return os.path.join(d, "r%d" % rnd, "%s.verdict.json" % mid)


def final_out(d):
    return os.path.join(d, "final.verdict.json")


def prompt_path(d, rnd, job_id):
    sub = "final" if rnd is None else "r%d" % rnd
    return os.path.join(d, "prompts", sub, job_id + ".md")


def _has_output(path):
    return os.path.isfile(path) and os.path.getsize(path) > 0


# ---------------------------------------------------------------- chaveamento

def new_state(n, seed, data, run_dir, wave=DEFAULT_WAVE, has_baseline=False):
    run_dir = os.path.abspath(run_dir)
    ids = agent_ids(n)
    agents = {}
    for aid, (r, w, s) in zip(ids, deal(n, seed, data)):
        agents[aid] = {
            "card": {
                "reasoning": dict(data["reasoning"][r]),
                "workflow": dict(data["workflows"][w]),
                "strategy": dict(data["strategies"][s]),
            },
            "solution": spawn_out(run_dir, aid),
            "alive": True,
            "eliminated_in": None,
            "eliminated_by": None,
            "byes": 0,
        }
    state = {
        "version": 1,
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "seed": seed,
        "agents_n": n,
        "cards_available": combo_count(data),
        "wave": wave,
        "dir": run_dir,
        "has_baseline": bool(has_baseline),
        "agents": agents,
        "rounds": [],
        "champion": None,
        "final": None,
    }
    open_round(state, ids)
    return state


def pair_round(state, rnd, alive):
    """Seeded pairing. An odd pool gives one bye, to an agent with the fewest byes so far.
    Where it can, it pairs agents with different reasoning modes, so every attack comes
    from a genuinely different angle. The first-listed side is random, which is the
    order the judge reads them in."""
    agents = state["agents"]
    rng = random.Random("arena-pair:%s:%d" % (state["seed"], rnd))
    pool = sorted(alive)
    rng.shuffle(pool)
    bye = None
    if len(pool) % 2:
        fewest = min(agents[a]["byes"] for a in pool)
        bye = next(a for a in pool if agents[a]["byes"] == fewest)
        pool.remove(bye)
    width = max(2, len(str(len(pool) // 2)))
    matches = []
    while pool:
        a = pool.pop(0)
        mode = agents[a]["card"]["reasoning"]["id"]
        j = next((k for k, b in enumerate(pool) if agents[b]["card"]["reasoning"]["id"] != mode), 0)
        b = pool.pop(j)
        if rng.random() < 0.5:
            a, b = b, a
        matches.append({
            "id": "r%d-m%0*d" % (rnd, width, len(matches) + 1),
            "a": a, "b": b,
            "winner": None, "loser": None, "reason": None,
            "survived": [], "scores": None, "source": None,
        })
    return matches, bye


def open_round(state, alive):
    """Abre a próxima rodada ou declara o campeão quando resta um concorrente."""
    alive = sorted(alive)
    if len(alive) == 1:
        state["champion"] = alive[0]
        if state.get("has_baseline") and not state.get("final"):
            rng = random.Random("arena-final:%s" % state["seed"])
            x = "champion" if rng.random() < 0.5 else "baseline"
            state["final"] = {"X": x, "Y": "baseline" if x == "champion" else "champion", "result": None}
        return None
    rnd = len(state["rounds"]) + 1
    matches, bye = pair_round(state, rnd, alive)
    rd = {"n": rnd, "alive": alive, "matches": matches, "bye": bye, "closed": False}
    state["rounds"].append(rd)
    return rd


def current_round(state):
    if state["champion"] or not state["rounds"]:
        return None
    rd = state["rounds"][-1]
    return None if rd["closed"] else rd


def norm_agent(state, raw):
    raw = str(raw).strip().lower()
    if raw in state["agents"]:
        return raw
    digits = raw.lstrip("a")
    if digits.isdigit():
        for aid in state["agents"]:
            if int(aid[1:]) == int(digits):
                return aid
    raise ArenaError("não existe concorrente chamado '%s'" % raw)


def find_match(state, mid):
    rd = current_round(state)
    if rd is None:
        raise ArenaError("não há uma rodada aberta" + (" (a arena já tem uma pessoa campeã)" if state["champion"] else ""))
    raw = str(mid).strip().lower()
    for m in rd["matches"]:
        if m["id"] == raw:
            return rd, m
    tail = raw.split("-m")[-1].lstrip("m")
    if tail.isdigit():
        for m in rd["matches"]:
            if int(m["id"].split("-m")[-1]) == int(tail):
                return rd, m
    raise ArenaError("não existe o confronto '%s' na rodada %d (execute pairings)" % (mid, rd["n"]))


def record(state, mid, winner, reason=None, survived=None, scores=None, source="manual"):
    rd, m = find_match(state, mid)
    winner = norm_agent(state, winner)
    if winner not in (m["a"], m["b"]):
        raise ArenaError("%s não participa de %s (%s vs %s)" % (winner, m["id"], m["a"], m["b"]))
    previous = m["winner"]
    m["winner"] = winner
    m["loser"] = m["b"] if winner == m["a"] else m["a"]
    m["reason"] = reason or None
    m["survived"] = list(survived or [])
    m["scores"] = scores
    m["source"] = source
    return m, previous


def advance(state):
    """Close the current round: eliminate every loser, carry the winners' revised
    solutions forward, give the bye its free pass, and open the next round."""
    rd = current_round(state)
    if rd is None:
        raise ArenaError("não há uma rodada aberta" + (" (a arena já tem uma pessoa campeã)" if state["champion"] else ""))
    unrecorded = [m["id"] for m in rd["matches"] if not m["winner"]]
    if unrecorded:
        raise ArenaError("a rodada %d tem %d confronto(s) sem resultado registrado: %s"
                         % (rd["n"], len(unrecorded), ", ".join(unrecorded)))
    survivors = []
    for m in rd["matches"]:
        loser = state["agents"][m["loser"]]
        loser["alive"] = False
        loser["eliminated_in"] = rd["n"]
        loser["eliminated_by"] = m["winner"]
        for aid in (m["a"], m["b"]):
            rev = revised_out(state["dir"], rd["n"], m["id"], aid)
            if _has_output(rev):
                state["agents"][aid]["solution"] = rev
        survivors.append(m["winner"])
    if rd["bye"]:
        state["agents"][rd["bye"]]["byes"] += 1
        survivors.append(rd["bye"])
    rd["closed"] = True
    open_round(state, survivors)
    return survivors


def rounds_played(state):
    return sum(1 for rd in state["rounds"] if rd["closed"])


def alive_ids(state):
    return sorted(a for a, v in state["agents"].items() if v["alive"])


# ---------------------------------------------------------------- vereditos

def weighted_total(scores):
    """Nota de 0 a 100 calculada a partir de cinco notas de 0 a 10, com pesos definidos em rubric.md. Retorna None se faltar alguma nota."""
    if not isinstance(scores, dict):
        return None
    total = 0.0
    for key, weight in WEIGHTS:
        v = scores.get(key)
        if isinstance(v, bool):
            return None
        try:
            v = float(v)
        except (TypeError, ValueError):
            return None
        total += max(0.0, min(10.0, v)) * weight
    return round(total / 10.0, 2)


def _truthy(v):
    if isinstance(v, str):
        return v.strip().lower() in ("true", "yes", "1")
    return bool(v)


def extract_json(text):
    text = text.strip()
    try:
        return json.loads(text)
    except ValueError:
        pass
    i, j = text.find("{"), text.rfind("}")
    if i != -1 and j > i:
        try:
            return json.loads(text[i:j + 1])
        except ValueError:
            return None
    return None


def decide(verdict, a, b):
    """Apply the rubric's arithmetic to a judge's verdict.

    The winner is the higher weighted total. A fatal solution cannot beat a
    non-fatal one. On an exact tie: fewer standing attacks, then higher
    correctness, then the judge's own pick. If the judge's pick disagrees with its
    own scores, the scores win and the note says so.
    Returns (winner, {a: total, b: total}, note).
    """
    if not isinstance(verdict, dict):
        raise ArenaError("o veredito não é um objeto JSON")
    raw_scores = verdict.get("scores") or {}
    scores = {str(k).strip().lower(): v for k, v in raw_scores.items()} if isinstance(raw_scores, dict) else {}
    sa, sb = scores.get(a), scores.get(b)
    pick_raw = str(verdict.get("winner") or "").strip().lower()
    in_a = re.search(r"\b%s\b" % re.escape(a), pick_raw) is not None
    in_b = re.search(r"\b%s\b" % re.escape(b), pick_raw) is not None
    pick = a if (in_a and not in_b) else b if (in_b and not in_a) else None
    ta, tb = weighted_total(sa), weighted_total(sb)
    totals = {a: ta, b: tb}
    if ta is None or tb is None:
        if pick:
            return pick, totals, "notas incompletas; foi usada a escolha do juiz"
        raise ArenaError("o veredito não tem pontuações completas nem indica um vencedor com clareza")
    fa, fb = _truthy(sa.get("fatal")), _truthy(sb.get("fatal"))
    if fa != fb:
        winner = b if fa else a
    elif ta != tb:
        winner = a if ta > tb else b
    else:
        standing = verdict.get("standing") if isinstance(verdict.get("standing"), dict) else {}
        standing = {str(k).strip().lower(): v for k, v in standing.items()}
        na = len(standing.get(a) or []) if isinstance(standing.get(a), list) else None
        nb = len(standing.get(b) or []) if isinstance(standing.get(b), list) else None
        ca, cb = float(sa.get("correctness", 0)), float(sb.get("correctness", 0))
        if na is not None and nb is not None and na != nb:
            winner = a if na < nb else b
        elif ca != cb:
            winner = a if ca > cb else b
        elif pick:
            winner = pick
        else:
            raise ArenaError("empate exato e o juiz não escolheu um vencedor")
    note = ""
    if pick and pick != winner:
        note = "o juiz escolheu %s, mas as próprias notas favorecem %s; as notas prevalecem" % (pick, winner)
    return winner, totals, note


def collect(state):
    """Record every verdict the judges have written for the open round (or the final
    check). An unreadable verdict is set aside as <name>.unreadable so the judge job
    shows up as missing again and gets re-run."""
    d = state["dir"]
    results = []
    if state["champion"]:
        fin = state.get("final")
        if not fin or fin.get("result"):
            return results
        path = final_out(d)
        if not _has_output(path):
            return [("final", "missing", "")]
        with open(path, encoding="utf-8", errors="replace") as fh:
            v = extract_json(fh.read())
        try:
            if isinstance(v, dict) and isinstance(v.get("scores"), dict):
                v = dict(v, scores={str(k).strip().lower(): s for k, s in v["scores"].items()})
            w, totals, note = decide(v, "x", "y")
        except ArenaError as e:
            os.replace(path, path + ".unreadable")
            return [("final", "unreadable", str(e))]
        better = fin[w.upper()]
        fin["result"] = {
            "better": better,
            "champion_total": totals["x" if fin["X"] == "champion" else "y"],
            "baseline_total": totals["x" if fin["X"] == "baseline" else "y"],
            "reason": str(v.get("reason") or "")[:400],
            "fixed": [str(x) for x in (v.get("fixed") or [])][:10] if isinstance(v.get("fixed"), list) else [],
        }
        return [("final", "recorded", ("%s é melhor. %s" % (better, note)).strip())]
    rd = current_round(state)
    if rd is None:
        return results
    for m in rd["matches"]:
        if m["winner"]:
            continue
        path = verdict_out(d, rd["n"], m["id"])
        if not _has_output(path):
            results.append((m["id"], "missing", ""))
            continue
        with open(path, encoding="utf-8", errors="replace") as fh:
            v = extract_json(fh.read())
        try:
            winner, totals, note = decide(v, m["a"], m["b"])
        except ArenaError as e:
            os.replace(path, path + ".unreadable")
            results.append((m["id"], "unreadable", str(e)))
            continue
        survived = v.get("survived") if isinstance(v.get("survived"), list) else []
        record(state, m["id"], winner,
               reason=str(v.get("reason") or "")[:400],
               survived=[str(x) for x in survived][:10],
               scores=totals, source="judge")
        loser = m["loser"]
        line = "%s venceu %s, %s a %s" % (winner, loser, _fmt(totals[winner]), _fmt(totals[loser]))
        results.append((m["id"], "recorded", line + (". " + note if note else "")))
    return results


def _fmt(x):
    return "?" if x is None else ("%g" % x)


# ---------------------------------------------------------------- tarefas e briefings

def phase_jobs(state, phase):
    """Every sub-agent job for a phase, with its prompt file and the outputs it must write.
    Matches that already have a recorded winner are skipped."""
    if phase not in PHASES:
        raise ArenaError("etapa desconhecida '%s' (opções: %s)" % (phase, ", ".join(PHASES)))
    d = state["dir"]
    jobs = []
    if phase == "spawn":
        for aid in sorted(state["agents"]):
            jobs.append({"id": aid + ".spawn", "kind": "competitor", "round": 0, "agent": aid,
                         "outputs": [spawn_out(d, aid)]})
    elif phase == "final":
        fin = state.get("final")
        if state["champion"] and fin and not fin.get("result"):
            jobs.append({"id": "final.judge", "kind": "final", "round": None, "outputs": [final_out(d)]})
    else:
        rd = current_round(state)
        if rd is None:
            return []
        n = rd["n"]
        for m in rd["matches"]:
            if m["winner"]:
                continue
            a, b = m["a"], m["b"]
            if phase == "attack":
                for me, opp in ((a, b), (b, a)):
                    jobs.append({"id": "%s.%s.attack" % (m["id"], me), "kind": "attacker", "round": n,
                                 "agent": me, "opponent": opp, "match": m["id"],
                                 "outputs": [attack_out(d, n, m["id"], me)]})
            elif phase == "defend":
                for me, opp in ((a, b), (b, a)):
                    jobs.append({"id": "%s.%s.defend" % (m["id"], me), "kind": "defender", "round": n,
                                 "agent": me, "opponent": opp, "match": m["id"],
                                 "outputs": [defense_out(d, n, m["id"], me), revised_out(d, n, m["id"], me)]})
            else:
                jobs.append({"id": "%s.judge" % m["id"], "kind": "judge", "round": n,
                             "match": m["id"], "a": a, "b": b,
                             "outputs": [verdict_out(d, n, m["id"])]})
    for j in jobs:
        j["prompt"] = prompt_path(d, j["round"], j["id"])
    return jobs


def missing_jobs(jobs):
    return [j for j in jobs if not all(_has_output(p) for p in j["outputs"])]


_TEMPLATE_RE = re.compile(r"<!-- template:([a-z]+) -->\s*```text\n(.*?)\n```\s*<!-- /template:\1 -->", re.S)
_PLACEHOLDER_RE = re.compile(r"\{\{(\w+)\}\}")


def load_templates(path=SKILL_PATH):
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    found = {m.group(1): m.group(2) for m in _TEMPLATE_RE.finditer(text)}
    missing = [t for t in TEMPLATES if t not in found]
    if missing:
        raise ArenaError("faltam modelos de prompt em SKILL.md: %s" % ", ".join(missing))
    return found


def fill(template, values):
    """Substitui os marcadores em uma única passagem para preservar literalmente tarefas que contenham {{chaves}}."""
    wanted = set(_PLACEHOLDER_RE.findall(template))
    missing = sorted(wanted - set(values))
    if missing:
        raise ArenaError("não há valor para o(s) marcador(es): %s" % ", ".join(missing))
    return _PLACEHOLDER_RE.sub(lambda m: str(values[m.group(1)]), template)


def read_task(state):
    """A tarefa exatamente como init a gravou (init acrescenta uma quebra de linha ao final do arquivo)."""
    with open(os.path.join(state["dir"], "task.md"), encoding="utf-8") as fh:
        return fh.read().rstrip("\n")


def _card_values(card):
    return {
        "reasoning_name": card["reasoning"]["name"], "reasoning_how": card["reasoning"]["how"],
        "workflow_name": card["workflow"]["name"], "workflow_how": card["workflow"]["how"],
        "strategy_name": card["strategy"]["name"], "strategy_how": card["strategy"]["how"],
    }


def render_job(state, job, templates, task):
    d = state["dir"]
    agents = state["agents"]
    v = {"task": task, "arena_dir": d, "rubric": os.path.join(d, "rubric.md"), "n": state["agents_n"]}
    kind = job["kind"]
    if kind == "competitor":
        aid = job["agent"]
        v.update(_card_values(agents[aid]["card"]))
        if state.get("has_baseline"):
            v["baseline_note"] = (
                "A pessoa já recebeu uma resposta para esta tarefa e não ficou satisfeita com ela. O arquivo está em "
                "%s. Leia-a primeiro e descubra exatamente onde ela falhou. Depois, supere-a. Não basta "
                "melhorá-la um pouco: no fim, a solução vencedora será comparada com essa resposta."
                % os.path.join(d, "baseline.md"))
        else:
            v["baseline_note"] = "Não há resposta anterior a superar. Comece pela tarefa."
        v.update(agent=aid, out=job["outputs"][0])
    elif kind == "attacker":
        me, opp = job["agent"], job["opponent"]
        v.update(_card_values(agents[me]["card"]))
        v.update(agent=me, target=opp, match=job["match"], round=job["round"],
                 own_solution=agents[me]["solution"], target_solution=agents[opp]["solution"],
                 out=job["outputs"][0])
    elif kind == "defender":
        me, opp = job["agent"], job["opponent"]
        v.update(_card_values(agents[me]["card"]))
        v.update(agent=me, attacker=opp, match=job["match"], round=job["round"],
                 own_solution=agents[me]["solution"],
                 attacks=attack_out(d, job["round"], job["match"], opp),
                 defense_out=job["outputs"][0], solution_out=job["outputs"][1])
    elif kind == "judge":
        n, mid, a, b = job["round"], job["match"], job["a"], job["b"]
        v.update(match=mid, round=n, first=a, second=b,
                 first_solution=revised_out(d, n, mid, a), second_solution=revised_out(d, n, mid, b),
                 first_attacks=attack_out(d, n, mid, b), second_attacks=attack_out(d, n, mid, a),
                 first_defense=defense_out(d, n, mid, a), second_defense=defense_out(d, n, mid, b),
                 out=job["outputs"][0])
    elif kind == "final":
        v.update(rounds=rounds_played(state),
                 x_solution=os.path.join(d, "final", "X.md"),
                 y_solution=os.path.join(d, "final", "Y.md"),
                 out=job["outputs"][0])
    return fill(templates[kind], v)


def write_prompts(state, phase):
    jobs = phase_jobs(state, phase)
    if not jobs:
        return jobs
    templates = load_templates()
    task = read_task(state)
    for j in jobs:
        for p in j["outputs"] + [j["prompt"]]:
            os.makedirs(os.path.dirname(p), exist_ok=True)
        body = render_job(state, j, templates, task)
        with open(j["prompt"], "w", encoding="utf-8") as fh:
            fh.write(body + "\n")
    if phase == "spawn":
        for aid in state["agents"]:
            os.makedirs(os.path.join(state["dir"], "scratch", aid), exist_ok=True)
    if phase == "final":
        # Cópias às cegas: o juiz final recebe X e Y sem saber qual é a solução campeã.
        fin = state["final"]
        sources = {"champion": state["agents"][state["champion"]]["solution"],
                   "baseline": os.path.join(state["dir"], "baseline.md")}
        os.makedirs(os.path.join(state["dir"], "final"), exist_ok=True)
        for label in ("X", "Y"):
            with open(sources[fin[label]], encoding="utf-8", errors="replace") as src, \
                    open(os.path.join(state["dir"], "final", label + ".md"), "w", encoding="utf-8") as dst:
                dst.write(src.read())
    return jobs


def next_action(state):
    """(phase, jobs_left, jobs_total). phase is one of spawn, attack, defend, judge,
    final, collect, advance, done."""
    spawn = phase_jobs(state, "spawn")
    left = missing_jobs(spawn)
    if left:
        return "spawn", left, spawn
    if state["champion"]:
        fin = state.get("final")
        if fin and not fin.get("result"):
            jobs = phase_jobs(state, "final")
            left = missing_jobs(jobs)
            return ("final", left, jobs) if left else ("collect", [], jobs)
        return "done", [], []
    for phase in ("attack", "defend", "judge"):
        jobs = phase_jobs(state, phase)
        left = missing_jobs(jobs)
        if left:
            return phase, left, jobs
    rd = current_round(state)
    if any(not m["winner"] for m in rd["matches"]):
        return "collect", [], []
    return "advance", [], []


# ---------------------------------------------------------------- planejamento

def plan_rows(n, wave=DEFAULT_WAVE):
    rows = []
    for rnd, alive in enumerate(bracket_sizes(n)[:-1], start=1):
        m = alive // 2
        waves = 2 * math.ceil(2 * m / wave) + math.ceil(m / wave)
        rows.append({"round": rnd, "alive": alive, "matches": m, "bye": alive % 2,
                     "calls": CALLS_PER_MATCH * m, "waves": waves})
    return rows


def plan_totals(n, wave=DEFAULT_WAVE):
    rows = plan_rows(n, wave)
    calls = n + sum(r["calls"] for r in rows)
    waves = math.ceil(n / wave) + sum(r["waves"] for r in rows)
    return {"agents": n, "rounds": len(rows), "calls": calls, "waves": waves, "rows": rows}


# ---------------------------------------------------------------- leitura e gravação do estado

def run_dir_from(args):
    if getattr(args, "dir", None):
        return os.path.abspath(args.dir)
    latest = os.path.join(ROOT, LATEST)
    if os.path.isfile(latest):
        with open(latest, encoding="utf-8") as fh:
            return fh.read().strip()
    raise ArenaError("não há arena neste local. Execute init primeiro ou informe --dir")


def load_state(args):
    d = run_dir_from(args)
    path = os.path.join(d, STATE_FILE)
    if not os.path.isfile(path):
        raise ArenaError("não foi encontrado %s em %s" % (STATE_FILE, d))
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def save_state(state):
    path = os.path.join(state["dir"], STATE_FILE)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(state, fh, indent=1)
        fh.write("\n")
    os.replace(tmp, path)


def _cmd(*parts):
    return 'python3 "%s" %s' % (SELF, " ".join(parts))


def _card_line(card):
    return "%s + %s + %s" % (card["reasoning"]["name"], card["workflow"]["name"], card["strategy"]["name"])


# ---------------------------------------------------------------- comandos

def _agents_arg(args):
    if args.quick and args.agents is not None:
        raise ArenaError("use --quick ou --agents, não ambos")
    if args.quick:
        return QUICK_AGENTS
    return DEFAULT_AGENTS if args.agents is None else args.agents


def cmd_plan(args):
    n = _agents_arg(args)
    if n < 1:
        raise ArenaError("--agents precisa ser pelo menos 1")
    t = plan_totals(n, args.wave)
    if args.json:
        print(json.dumps(t, indent=1))
        return 0
    print("%d concorrentes, %d rodadas, ondas de %d" % (n, t["rounds"], args.wave))
    print("")
    print("  rodada ativos confrontos folga chamadas_subagentes ondas")
    print("  início %5d  %7s  %3s  %15d  %5d" % (n, "-", "-", n, math.ceil(n / args.wave)))
    for r in t["rows"]:
        print("  %5d  %5d  %7d  %3s  %15d  %5d"
              % (r["round"], r["alive"], r["matches"], "sim" if r["bye"] else "-", r["calls"], r["waves"]))
    print("  total                     %15d  %5d" % (t["calls"], t["waves"]))
    print("")
    print("  participantes por rodada: %s" % " -> ".join(str(s) for s in bracket_sizes(n)))
    print("  acrescente 1 chamada para a avaliação final quando houver uma resposta rejeitada a superar")
    return 0


def cmd_init(args):
    n = _agents_arg(args)
    if args.wave < 1:
        raise ArenaError("--wave precisa ser pelo menos 1")
    data = load_strategies()
    if n < 1 or n > combo_count(data):
        raise ArenaError("--agents precisa ficar entre 1 e %d (quantidade de cartões distintos)" % combo_count(data))
    if args.task_file:
        with open(args.task_file, encoding="utf-8") as fh:
            task = fh.read()
    else:
        task = args.task or ""
    task = task.strip()
    if not task:
        raise ArenaError("a tarefa está vazia. Informe --task-file ou --task")
    baseline = None
    if args.baseline_file:
        with open(args.baseline_file, encoding="utf-8") as fh:
            baseline = fh.read().strip()
        if not baseline:
            raise ArenaError("o arquivo de referência está vazio")
    seed = args.seed if args.seed is not None else random.SystemRandom().randrange(1, 1000000)
    default_dir = not args.dir
    d = os.path.abspath(args.dir or os.path.join(ROOT, "run-%s-s%s" % (time.strftime("%Y%m%d-%H%M%S"), seed)))
    if os.path.exists(os.path.join(d, STATE_FILE)):
        raise ArenaError("já existe uma arena em %s. Escolha outro valor para --dir" % d)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "task.md"), "w", encoding="utf-8") as fh:
        fh.write(task + "\n")
    if baseline:
        with open(os.path.join(d, "baseline.md"), "w", encoding="utf-8") as fh:
            fh.write(baseline + "\n")
    # A execução recebe uma cópia fixa da rubrica, guardada no próprio diretório para que
    # os juízes possam consultá-la sem pedir permissão para cada leitura.
    with open(RUBRIC_PATH, encoding="utf-8") as src, \
            open(os.path.join(d, "rubric.md"), "w", encoding="utf-8") as dst:
        dst.write(src.read())
    state = new_state(n, seed, data, d, wave=args.wave, has_baseline=bool(baseline))
    save_state(state)
    if default_dir:
        os.makedirs(ROOT, exist_ok=True)
        with open(os.path.join(ROOT, LATEST), "w", encoding="utf-8") as fh:
            fh.write(d + "\n")
    t = plan_totals(n, args.wave)
    print("arena pronta: %s" % d)
    print("seed %s. %d concorrentes receberam %d cartões distintos de um total de %d, sem repetição."
          % (seed, n, n, combo_count(data)))
    print("%d rodadas (%s). %d chamadas a subagentes em %d ondas de %d%s."
          % (t["rounds"], " -> ".join(str(s) for s in bracket_sizes(n)), t["calls"] + (1 if baseline else 0),
             t["waves"] + (1 if baseline else 0), args.wave, ", incluindo a avaliação final" if baseline else ""))
    print("próxima ação: %s" % _cmd("next"))
    return 0


def cmd_next(args):
    state = load_state(args)
    phase, left, jobs = next_action(state)
    rd = current_round(state)
    total_rounds = len(bracket_sizes(state["agents_n"])) - 1
    if phase == "spawn":
        print("criação: %d concorrentes, depois %d rodada(s)" % (state["agents_n"], total_rounds))
    elif rd:
        print("rodada %d de %d, %d concorrentes ativos" % (rd["n"], total_rounds, len(rd["alive"])))
    elif state["champion"]:
        print("campeão: %s após %d rodada(s)" % (state["champion"], rounds_played(state)))
    if phase in PHASES:
        print("PRÓXIMA ETAPA: %s. %d de %d tarefa(s) para executar." % (phase, len(left), len(jobs)))
        print("  1. %s" % _cmd("prompts", phase))
        print("  2. inicie as tarefas listadas, uma onda de %d por vez" % state["wave"])
        print("  3. %s" % _cmd("next"))
    elif phase == "collect":
        print("PRÓXIMA ETAPA: collect. Todos os vereditos desta etapa estão salvos.")
        print("  %s" % _cmd("collect"))
    elif phase == "advance":
        print("PRÓXIMA ETAPA: advance. Todos os confrontos da rodada %d têm vencedor." % rd["n"])
        print("  %s" % _cmd("advance"))
    else:
        print("DONE. %s" % _cmd("winner"))
    return 0


def cmd_prompts(args):
    state = load_state(args)
    jobs = write_prompts(state, args.phase)
    if not jobs:
        print("não há nada para executar em %s neste momento. %s" % (args.phase, _cmd("next")))
        return 0
    left = missing_jobs(jobs)
    w = state["wave"]
    rd = current_round(state)
    where = "rodada 0" if args.phase == "spawn" else ("avaliação final" if args.phase == "final" else "rodada %d" % rd["n"])
    waves = [left[i:i + w] for i in range(0, len(left), w)]
    print("%s, %s: %d tarefa(s), %d restante(s), %d onda(s) com até %d tarefas"
          % (where, args.phase, len(jobs), len(left), len(waves), w))
    for k, wave in enumerate(waves, start=1):
        print("onda %d" % k)
        for j in wave:
            print("  %-26s %s" % (j["id"], j["prompt"]))
    if left:
        print("")
        print("Cada tarefa corresponde a uma chamada de agente. No Claude Code, use subagent_type general-purpose e a descrição arena <id da tarefa>.")
        print("No prompt, informe: leia o caminho do briefing e siga-o à risca. Ele contém todas as instruções da tarefa.")
        print("Uma onda reúne todas as chamadas de agente correspondentes. Aguarde a conclusão antes de iniciar a próxima. Em outros ambientes, use a ferramenta nativa documentada.")
    print("em seguida: %s" % _cmd("next"))
    return 0


def cmd_check(args):
    state = load_state(args)
    jobs = phase_jobs(state, args.phase)
    left = missing_jobs(jobs)
    print("%s: %d de %d tarefa(s) concluída(s)" % (args.phase, len(jobs) - len(left), len(jobs)))
    for j in left:
        gone = [p for p in j["outputs"] if not _has_output(p)]
        print("  ausente  %-26s %s" % (j["id"], ", ".join(gone)))
    return 1 if left else 0


def cmd_pairings(args):
    state = load_state(args)
    rd = current_round(state)
    if rd is None:
        if state["champion"]:
            print("Não há mais confrontos. %s é a última pessoa concorrente." % state["champion"])
            return 0
        raise ArenaError("não há uma rodada aberta")
    if args.json:
        print(json.dumps(rd, indent=1))
        return 0
    agents = state["agents"]
    print("rodada %d: %d concorrentes ativos, %d confronto(s), folga: %s"
          % (rd["n"], len(rd["alive"]), len(rd["matches"]), rd["bye"] or "nenhuma"))
    for m in rd["matches"]:
        ra = agents[m["a"]]["card"]["reasoning"]["name"]
        rb = agents[m["b"]]["card"]["reasoning"]["name"]
        res = ("vencedor %s" % m["winner"]) if m["winner"] else "aberto"
        print("  %s  %s vs %s  (%s vs %s)  %s" % (m["id"], m["a"], m["b"], ra, rb, res))
    if rd["bye"]:
        print("  folga   %s avança sem confronto" % rd["bye"])
    return 0


def cmd_record(args):
    state = load_state(args)
    m, previous = record(state, args.match_id, args.winner_id, reason=args.reason,
                         survived=args.survived, source="manual")
    save_state(state)
    extra = " (antes: %s)" % previous if previous and previous != m["winner"] else ""
    print("%s: %s venceu %s%s" % (m["id"], m["winner"], m["loser"], extra))
    return 0


def cmd_collect(args):
    state = load_state(args)
    results = collect(state)
    save_state(state)
    if not results:
        print("nada para registrar. %s" % _cmd("next"))
        return 0
    bad = 0
    for mid, what, note in results:
        if what != "recorded":
            bad += 1
        print("  %-10s %-10s %s" % (mid, {"recorded": "registrado", "missing": "ausente", "unreadable": "ilegível"}.get(what, what), note))
    rd = current_round(state)
    if rd:
        done = sum(1 for m in rd["matches"] if m["winner"])
        print("rodada %d: %d de %d confronto(s) registrado(s)" % (rd["n"], done, len(rd["matches"])))
    if bad:
        print("%d veredito(s) ausente(s) ou ilegível(is). Execute esses juízes novamente: %s" % (bad, _cmd("next")))
        return 1
    print("em seguida: %s" % _cmd("next"))
    return 0


def cmd_advance(args):
    state = load_state(args)
    rd = current_round(state)
    closing = rd["n"] if rd else None
    survivors = advance(state)
    save_state(state)
    print("rodada %s encerrada: %d avançaram, %d foram eliminados"
          % (closing, len(survivors), len(rd["matches"])))
    if state["champion"]:
        print("CAMPEÃO: %s. %s" % (state["champion"], _cmd("next")))
    else:
        nr = state["rounds"][-1]
        print("rodada %d aberta: %d confronto(s)%s. %s"
              % (nr["n"], len(nr["matches"]), ", folga de %s" % nr["bye"] if nr["bye"] else "", _cmd("next")))
    return 0


def status_rows(state):
    rows = []
    for rd in state["rounds"]:
        recorded = sum(1 for m in rd["matches"] if m["winner"])
        rows.append({"round": rd["n"], "alive": len(rd["alive"]), "matches": len(rd["matches"]),
                     "bye": rd["bye"], "eliminated": recorded,
                     "state": "encerrada" if rd["closed"] else "aberta, %d de %d resultados registrados" % (recorded, len(rd["matches"]))})
    return rows


def cmd_status(args):
    state = load_state(args)
    rows = status_rows(state)
    alive = alive_ids(state)
    if args.json:
        print(json.dumps({"dir": state["dir"], "seed": state["seed"], "agents": state["agents_n"],
                          "alive": len(alive), "eliminated": state["agents_n"] - len(alive),
                          "champion": state["champion"], "rounds": rows}, indent=1))
        return 0
    print("arena %s" % state["dir"])
    print("seed %s, %d concorrentes, ondas de %d, %d cartões distintos disponíveis"
          % (state["seed"], state["agents_n"], state["wave"], state["cards_available"]))
    print("rodada  ativos  confrontos  folga  eliminados  estado")
    for r in rows:
        print("  %5d  %5d  %7d  %-6s  %10d  %s"
              % (r["round"], r["alive"], r["matches"], r["bye"] or "-", r["eliminated"], r["state"]))
    print("agora: %d ativos, %d eliminados%s"
          % (len(alive), state["agents_n"] - len(alive),
             ", campeão %s" % state["champion"] if state["champion"] else ""))
    return 0


def winner_report(state):
    champ = state["champion"]
    if not champ:
        return None
    agent = state["agents"][champ]
    path = []
    survived = []
    for rd in state["rounds"]:
        if rd["bye"] == champ:
            path.append({"round": rd["n"], "bye": True})
        for m in rd["matches"]:
            if champ in (m["a"], m["b"]):
                opp = m["b"] if m["a"] == champ else m["a"]
                sc = m.get("scores") or {}
                path.append({"round": rd["n"], "bye": False, "beat": opp, "match": m["id"],
                             "score": sc.get(champ), "opponent_score": sc.get(opp),
                             "reason": m.get("reason"), "survived": m.get("survived") or []})
                survived.extend(m.get("survived") or [])
    return {"champion": champ, "card": agent["card"], "card_line": _card_line(agent["card"]),
            "solution": agent["solution"], "rounds": rounds_played(state), "agents": state["agents_n"],
            "matches_won": sum(1 for p in path if not p["bye"]), "path": path,
            "attacks_survived": survived, "final": (state.get("final") or {}).get("result")}


def cmd_winner(args):
    state = load_state(args)
    rep = winner_report(state)
    if rep is None:
        rd = current_round(state)
        print("ainda não há vencedor: rodada %s, %d concorrentes ativos. %s"
              % (rd["n"] if rd else "?", len(alive_ids(state)), _cmd("next")))
        return 1
    if args.json:
        print(json.dumps(rep, indent=1))
        return 0
    print("CAMPEÃO   %s" % rep["champion"])
    print("cartão    %s" % rep["card_line"])
    print("solução   %s" % rep["solution"])
    print("rodadas   %d disputadas, %d concorrentes no início, 1 restante, %d confronto(s) vencido(s)"
          % (rep["rounds"], rep["agents"], rep["matches_won"]))
    for p in rep["path"]:
        if p["bye"]:
            print("  rodada %d  folga" % p["round"])
            continue
        print("  rodada %d  venceu %s, %s a %s. %s"
              % (p["round"], p["beat"], _fmt(p["score"]), _fmt(p["opponent_score"]), p["reason"] or ""))
        for s in p["survived"]:
            print("           críticas superadas: %s" % s)
    fin = rep["final"]
    if fin:
        verdict = ("a solução campeã venceu" if fin["better"] == "champion"
                   else "a resposta rejeitada recebeu nota maior; informe isso com clareza")
        print("comparação com a resposta rejeitada: campeã %s, resposta anterior %s; %s. %s"
              % (_fmt(fin["champion_total"]), _fmt(fin["baseline_total"]), verdict, fin["reason"]))
    return 0


def cmd_card(args):
    state = load_state(args)
    aid = norm_agent(state, args.agent_id)
    a = state["agents"][aid]
    c = a["card"]
    print("%s  %s" % (aid, "ativo" if a["alive"] else "eliminado na rodada %s por %s"
                      % (a["eliminated_in"], a["eliminated_by"])))
    for part in ("reasoning", "workflow", "strategy"):
        print("  %-9s %s. %s" % (part, c[part]["name"], c[part]["how"]))
    print("  solução   %s" % a["solution"])
    return 0


def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--dir", help="diretório desta arena (padrão: o indicado em .arena/LATEST)")
    p = argparse.ArgumentParser(prog="bracket.py", description="Estado do torneio /arena.")
    sub = p.add_subparsers(dest="cmd")
    sub.required = True

    s = sub.add_parser("plan", help="rodadas, chamadas a subagentes e ondas para N concorrentes")
    s.add_argument("--agents", type=int)
    s.add_argument("--quick", action="store_true")
    s.add_argument("--wave", type=int, default=DEFAULT_WAVE)
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_plan)

    s = sub.add_parser("init", parents=[common], help="distribui os cartões e grava arena.json")
    s.add_argument("--agents", type=int, help="número de concorrentes (padrão: %d)" % DEFAULT_AGENTS)
    s.add_argument("--quick", action="store_true", help="%d concorrentes" % QUICK_AGENTS)
    s.add_argument("--seed", type=int, help="fixa os cartões e confrontos (padrão: aleatório e registrado)")
    s.add_argument("--task-file", help="a tarefa, palavra por palavra, que todos os concorrentes receberão")
    s.add_argument("--task", help="a tarefa como texto, em vez de --task-file")
    s.add_argument("--baseline-file", help="a resposta anterior que a pessoa rejeitou")
    s.add_argument("--wave", type=int, default=DEFAULT_WAVE, help="subagentes simultâneos por onda (padrão: 10)")
    s.set_defaults(func=cmd_init)

    s = sub.add_parser("next", parents=[common], help="mostra a próxima ação")
    s.set_defaults(func=cmd_next)

    for name, fn, hlp in (("prompts", cmd_prompts, "cria os briefings de uma etapa e lista as tarefas restantes"),
                          ("check", cmd_check, "lista as tarefas sem resultado")):
        s = sub.add_parser(name, parents=[common], help=hlp)
        s.add_argument("phase", choices=PHASES)
        s.set_defaults(func=fn)

    s = sub.add_parser("pairings", parents=[common], help="confrontos da rodada atual, incluindo quem avançou sem jogar")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_pairings)

    s = sub.add_parser("record", parents=[common], help="registra manualmente o resultado de um confronto")
    s.add_argument("match_id")
    s.add_argument("winner_id")
    s.add_argument("--reason")
    s.add_argument("--survived", action="append", help="uma crítica superada pelo vencedor (pode ser repetida)")
    s.set_defaults(func=cmd_record)

    s = sub.add_parser("collect", parents=[common], help="registra todos os vereditos dos juízes")
    s.set_defaults(func=cmd_collect)

    s = sub.add_parser("advance", parents=[common], help="encerra a rodada e organiza os confrontos entre sobreviventes")
    s.set_defaults(func=cmd_advance)

    s = sub.add_parser("status", parents=[common], help="participantes ativos e eliminados em cada rodada")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_status)

    s = sub.add_parser("winner", parents=[common], help="a solução sobrevivente e seu percurso")
    s.add_argument("--json", action="store_true")
    s.set_defaults(func=cmd_winner)

    s = sub.add_parser("card", parents=[common], help="cartão de estratégia de um concorrente")
    s.add_argument("agent_id")
    s.set_defaults(func=cmd_card)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except ArenaError as e:
        print("erro: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())

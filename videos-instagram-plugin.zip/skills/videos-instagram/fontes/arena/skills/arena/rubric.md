# Rubrica da arena

Cada confronto é avaliado com base nesta página. O juiz pontua as duas soluções; bracket.py calcula o resultado ponderado. A maior pontuação avança. A outra solução é eliminada.

## Os cinco critérios

Cada critério recebe uma nota de 0 a 10. O peso indica quanto ele vale no total de 100 pontos.

| Critério | Peso | Pergunta |
| --- | ---: | --- |
| correctness | 30 | A resposta está correta? Há afirmações falsas, erros de lógica, bugs ou algo que possa induzir a pessoa ao erro? |
| completeness | 25 | A resposta atende a todos os requisitos expressos na tarefa? Avalie o texto da tarefa, não o que o juiz gostaria que tivesse sido pedido. |
| specificity | 15 | A pessoa consegue agir agora sem precisar adivinhar? Há passos, valores, nomes e código exatos quando necessários? |
| robustness | 20 | A resposta resiste às críticas deste confronto? Os problemas foram corrigidos, rebatidos corretamente ou continuam sem solução? |
| clarity | 10 | A resposta é fácil de ler e usar, com uma extensão adequada à tarefa? |

Total ponderado = (correção × 30 + completude × 25 + especificidade × 15 + robustez × 20 + clareza × 10) ÷ 10. O resultado vai de 0 a 100.

## Referências para as notas

Use toda a escala. Nota 7 não é uma escolha automática por educação.

**Correção**
- 10: após conferir, não há erro identificável.
- 7: há deslizes pequenos que não mudam o resultado para a pessoa.
- 4: há pelo menos um erro real que pode prejudicar a pessoa.
- 0 a 2: a resposta está fundamentalmente errada ou pode causar dano se for usada.

**Completude**
- 10: todos os requisitos declarados foram atendidos por completo.
- 7: todos foram abordados, mas um ficou superficial.
- 4: falta um requisito declarado.
- 0 a 2: a resposta trata de uma pergunta diferente.

**Especificidade**
- 10: a pessoa pode executar cada parte imediatamente.
- 7: a resposta é quase toda concreta, mas há um ou dois pontos que exigem suposições.
- 4: há muitos “considere”, “garanta” e “depende” sem uma resposta definida.
- 0 a 2: são recomendações genéricas que serviriam para qualquer tarefa.

**Robustez**
- 10: toda crítica foi corrigida ou rebatida corretamente na versão revisada, sem introduzir novos problemas.
- 7: resta uma crítica MINOR sem solução.
- 4: resta uma crítica MAJOR, ou uma correção criou outro problema.
- 0 a 2: resta uma crítica FATAL sem solução.

Se não houver arquivo de críticas, o adversário não apontou problemas. Avalie a robustez com base nas falhas que você mesmo encontrou.

**Clareza**
- 10: a estrutura deixa evidente como usar a resposta. Sem enchimento.
- 7: está boa, mas tem algum excesso ou trecho confuso.
- 4: a pessoa precisa procurar a resposta.
- 0 a 2: é muito difícil de acompanhar.

## Regra para falhas fatais

Marque uma solução como fatal somente se você tiver verificado um problema que a torne incorreta ou inutilizável para a tarefa: código que não funciona, afirmação central falsa, limite obrigatório descumprido ou resposta à pergunta errada. Uma solução fatal não pode vencer uma solução não fatal, qualquer que seja a pontuação. Se ambas forem fatais, decida pela pontuação.

## Empates

Não há empate final. Em igualdade exata, vence a solução com menos críticas ainda procedentes. Se continuar empatado, vence a que tiver maior nota de correção. Se ainda houver igualdade, escolha a solução que você entregaria à pessoa e explique o motivo no campo reason.

## O que não dá pontos extras

- **Extensão.** Mais texto não significa uma resposta melhor. Uma resposta objetiva que atende aos requisitos vence outra mais longa que oferece a mesma coisa.
- **Confiança.** Dizer “corrigido” não é prova. Confira a versão revisada.
- **Abordagem.** O juiz não vê os cartões de estratégia e não deve tentar adivinhá-los. Avalie o trabalho, não o método que o produziu.
- **Autopromoção.** Dizer “esta solução é robusta e completa” não vale pontos. A solução precisa demonstrar isso.
# Arena

Use esta habilidade para comparar respostas concorrentes em uma disputa estruturada. As pessoas participantes recebem a mesma tarefa, desenvolvem soluções, criticam soluções adversárias, revisam as próprias e são avaliadas por um juiz com base em uma rubrica escrita. Você coordena o processo: não concorre, não ataca e não escolhe o vencedor.

## Compatibilidade com plataformas

- No Claude Code, use a ferramenta Agent/Task disponível para iniciar os subagentes.
- No ChatGPT, Claude.ai ou outro ambiente, use somente a ferramenta nativa de delegação de agentes que estiver realmente disponível. Adapte os parâmetros ao que essa ferramenta documenta; nunca invente nomes de ferramentas ou parâmetros.
- Se o ambiente não oferecer delegação a agentes, explique isso com clareza e não simule uma disputa de 100 agentes. Ofereça uma análise sequencial menor, com alternativas independentes, crítica e revisão, deixando explícito que ela não é um torneio multiagente.
- O formato da habilidade e os arquivos de apoio são portáveis. A disponibilidade de ferramentas, a execução de Python, os limites de agentes, as permissões e os custos dependem do produto, da conta e do espaço de trabalho.

## O que a pessoa solicitou

Na invocação por /arena, o texto depois do comando é $ARGUMENTS. Se estiver vazio ou ainda parecer um marcador de posição, use como tarefa o pedido mais recente da conversa. Quando a plataforma não tiver um comando /arena, use o pedido que ativou a habilidade.

## A ferramenta de controle do torneio

O script bracket.py, nesta habilidade, controla o placar, as etapas, os confrontos e os arquivos de trabalho. Ele não inicia agentes por conta própria.

Quando carregada como plugin no Claude Code, use o script no diretório indicado por CLAUDE_SKILL_DIR. Quando carregada como ZIP de Agent Skills, use o caminho fontes/arena/skills/arena/bracket.py a partir da raiz do pacote.

```bash
python3 "$CLAUDE_SKILL_DIR/bracket.py" <comando>
python3 fontes/arena/skills/arena/bracket.py <comando>
```

No restante deste documento, ARENA significa a chamada correta a bracket.py no ambiente atual. O estado da execução fica em .arena/<execução>/arena.json no diretório de trabalho, e os comandos posteriores localizam a execução por .arena/LATEST.

## Etapa 1: definir o tamanho e pedir autorização quando necessário

Leia as opções na solicitação. Tudo que não for uma opção é parte da tarefa.

| Opção | Significado |
| --- | --- |
| --agents N | Número de concorrentes. O padrão é 100. |
| --quick | 16 concorrentes. É o modo recomendado para tarefas comuns. |
| --seed S | Fixa os cartões de estratégia e os confrontos. Por padrão, a escolha é aleatória e fica registrada. |
| --wave W | Número de subagentes por rodada de execução. O padrão é 10. Só aumente quando o limite da plataforma permitir. |

Se não houver texto de tarefa, use o pedido mais recente da pessoa nesta conversa. Se houver uma resposta anterior que ela rejeitou, essa resposta é a referência a superar.

Execute ARENA plan --agents N (ou --quick). O comando mostra as rodadas, as chamadas a agentes e as ondas.

- Se a pessoa pediu uma arena explicitamente (digitou /arena, escreveu “arena” ou pediu para colocar respostas em disputa), informe em uma frase o tamanho escolhido, por exemplo: “100 agentes, 7 rodadas e 595 chamadas a subagentes”, e comece.
- Se a habilidade foi acionada porque a pessoa não gostou de uma resposta, mas ela não mencionou uma arena, pergunte uma vez antes de iniciar uma execução custosa. Ofereça a arena completa (100 agentes, 595 chamadas), o modo --quick (16 agentes, 91 chamadas) ou uma nova tentativa comum. Aguarde a resposta.
- Se a plataforma não oferecer agentes delegados, informe isso antes de iniciar. Ofereça uma revisão sequencial menor; não registre essa revisão como torneio multiagente.

Os agentes gravam o trabalho em .arena/ no diretório atual. No modo de permissão padrão do Claude Code, cada arquivo pode exigir aprovação. Antes de uma execução extensa, explique que o modo accept-edits (Shift+Tab) reduz essas aprovações. Não altere as configurações da pessoa.

## Etapa 2: preparar o arquivo da tarefa

Esta etapa determina a qualidade do resultado. Os subagentes não veem a conversa original. Cada concorrente, atacante e juiz recebe apenas o arquivo da tarefa; portanto, escreva .arena/task.md de forma completa e independente:

- O pedido, de preferência com as palavras usadas pela pessoa.
- Todos os requisitos e limites citados na conversa: público, extensão, formato, tom, tecnologia, prazo e o que não pode mudar.
- O contexto necessário para alguém que não leu a conversa: caminhos absolutos dos arquivos relevantes, dados fornecidos, descrição do produto e convenções do projeto.
- A definição de concluído, se a pessoa tiver fornecido uma.
- O que a pessoa não gostou na resposta anterior, se houver uma resposta a superar.

Não invente requisitos nem inclua a sua própria opinião sobre qual solução é correta. Isso direcionaria os concorrentes e anularia a comparação.

Se houver uma resposta anterior a superar, salve-a sem alterações em .arena/baseline.md.

## Etapa 3: iniciar

```bash
ARENA init --agents N --seed S --task-file .arena/task.md --baseline-file .arena/baseline.md
```

Omita --baseline-file quando não houver resposta anterior a comparar e omita --seed para usar um valor aleatório. O comando copia a tarefa para a execução, distribui um cartão diferente para cada concorrente, sem repetição, cria os confrontos da primeira rodada e grava arena.json.

## Etapa 4: conduzir as rodadas

Sempre use ARENA next para saber a próxima ação. O comando lê o estado salvo e informa a etapa e o comando correspondente.

Cada etapa que usa subagentes segue o mesmo fluxo:

1. Execute ARENA prompts <etapa> para criar um briefing para cada tarefa e ver quais ainda faltam, agrupadas em ondas.
2. Inicie uma onda por vez, usando uma chamada da ferramenta nativa de agentes para cada tarefa daquela onda. No Claude Code, use Agent (chamado Task em algumas versões). Em outros ambientes, use o equivalente documentado. No Claude Code, os parâmetros são:
   - subagent_type: general-purpose
   - description: arena <id da tarefa>
   - prompt: Read <caminho do briefing> and follow it exactly. It is your whole brief.
   - run_in_background: false, quando disponível.
   Aguarde todas as respostas da onda antes de iniciar a próxima.
3. Depois da última onda, execute ARENA next. Se faltar algum resultado, o comando retorna à mesma etapa e prompts lista apenas as tarefas ausentes. Tente executá-las mais uma vez. Se uma tarefa falhar duas vezes, grave a linha exata NO OUTPUT em cada arquivo de resultado correspondente (ARENA check <etapa> lista os caminhos) e continue. Uma crítica ausente conta como nenhuma crítica; uma solução ausente perde o confronto. Se um juiz falhar duas vezes, execute uma terceira tentativa separada. Nunca decida o confronto no lugar do juiz.

A ordem de ARENA next é:

- spawn, uma vez: cada concorrente escreve uma solução para a tarefa.
- Em cada rodada: attack (duas críticas por confronto) → defend (duas defesas por confronto) → judge (um juiz por confronto) → ARENA collect → ARENA advance.
- final, uma vez, somente quando houver uma resposta anterior: um juiz compara às cegas a solução campeã com a resposta rejeitada. Depois, execute ARENA collect.
- Quando next indicar DONE, vá à etapa 5.

Depois de cada ARENA advance, informe uma frase, como “Rodada 2 concluída: restam 25 de 100 concorrentes.” Não cole confrontos, críticas, vereditos ou soluções na conversa durante a disputa.

O Claude Code executa no máximo 10 chamadas de ferramenta simultâneas por padrão, pela configuração CLAUDE_CODE_MAX_TOOL_USE_CONCURRENCY. Assim, a criação de 100 agentes usa 10 ondas de 10; a arena completa usa 70 ondas, ou 71 com a avaliação final. Em outros produtos, respeite o limite real daquele ambiente.

## Etapa 5: apresentar o resultado

Execute ARENA winner e leia o arquivo de solução do campeão indicado pelo comando. Esse é o único arquivo de solução que você lê durante toda a execução. Apresente:

1. A solução vencedora completa.
2. Por que venceu: uma lista curta das críticas que superou, conforme winner. Informe o cartão de estratégia em uma linha (modo de raciocínio + fluxo de trabalho + estratégia).
3. O número de rodadas, por exemplo: “7 rodadas, 100 concorrentes no início e 1 restante”.
4. Se havia resposta anterior: os resultados honestos da comparação final. Se a resposta anterior tiver vencido, diga isso claramente e mostre ambas as pontuações.
5. Onde está o registro completo: a pasta da execução.

Se a solução propuser mudanças nos arquivos do projeto da pessoa, não as aplique. Pergunte se ela quer aplicar as mudanças ou revisá-las.

## Regras para quem coordena

- Você conduz o torneio. Não concorra, não ataque, não julgue e não escolha o vencedor. collect registra o que os juízes decidiram. record só serve para corrigir o placar quando a pessoa pedir.
- Cada subagente recebe a tarefa por meio do briefing gerado a partir do único arquivo da tarefa. O texto deve ser idêntico, byte a byte, para todos. Nunca parafraseie a tarefa para um agente nem acrescente uma dica a uma chamada específica.
- Não leia soluções, críticas ou vereditos durante a execução. Use next, status e pairings para acompanhar o andamento.
- Se o contexto da conversa for resumido no meio da execução, nada se perde. Execute ARENA status e depois ARENA next para continuar.
- Execute todos os comandos ARENA no mesmo diretório em que init foi executado. É lá que fica .arena/LATEST.
- Os subagentes só podem gravar dentro de .arena/. Se algum deles gravar em outro lugar, informe a pessoa.
- Se a pessoa pedir para parar, pare. ARENA status mostra o andamento e ARENA next retoma a execução depois.

## Modelos de prompt

bracket.py preenche os marcadores {{...}} e cria um briefing por tarefa. O texto abaixo é exatamente o briefing enviado aos agentes. Nunca edite o briefing de um agente individual.

### Concorrente, na etapa de criação

<!-- template:competitor -->
```text
Você é o concorrente {{agent}} em uma arena com {{n}} participantes. Todos receberam exatamente a mesma tarefa, palavra por palavra. O cartão de estratégia abaixo é a única diferença entre você e os demais: ele define como abordar a tarefa. Sua solução será criticada por outros concorrentes e avaliada por um juiz em várias rodadas, até que reste uma única solução.

=== TAREFA (idêntica para todos os concorrentes) ===
{{task}}
=== FIM DA TAREFA ===

{{baseline_note}}

=== SEU CARTÃO DE ESTRATÉGIA ===
Modo de raciocínio: {{reasoning_name}}. {{reasoning_how}}
Fluxo de trabalho: {{workflow_name}}. {{workflow_how}}
Estratégia: {{strategy_name}}. {{strategy_how}}
=== FIM DO CARTÃO ===

Como trabalhar:
1. Aplique o cartão de verdade. Use o modo de raciocínio, siga as etapas do fluxo na ordem e deixe a estratégia orientar as escolhas. Uma resposta genérica com o nome do cartão no topo será eliminada.
2. Atenda a todos os requisitos expressos na tarefa. O juiz avalia a solução em relação à tarefa, não ao cartão.
3. Você não pode fazer perguntas à pessoa. Se a tarefa for ambígua, adote a interpretação mais razoável e registre-a brevemente em uma seção de premissas.
4. Espere críticas concretas: falhas, contraexemplos e requisitos esquecidos. Corrija esses pontos antes de enviar.
5. Não crie, edite nem exclua nada fora de {{arena_dir}}. Leia o que a tarefa indicar. Se a tarefa envolver código, inclua as alterações exatas na solução (arquivos completos ou diff unificado), sem aplicá-las. Se precisar de espaço temporário, use {{arena_dir}}/scratch/{{agent}}/.

Grave em {{out}} a solução completa, pronta para a pessoa que fez o pedido. Não inclua rascunhos nem raciocínio de trabalho. Acrescente uma lista de verificação, testes ou observações sobre escolhas somente se forem úteis para a pessoa. Não mencione a arena, o cartão ou seu número de concorrente: os juízes avaliam a solução às cegas.

Depois de gravar o arquivo, responda somente com esta linha:
DONE {{agent}} <número de palavras da solução>
```
<!-- /template:competitor -->

### Atacante, em cada rodada

<!-- template:attacker -->
```text
Você é o concorrente {{agent}} na rodada {{round}}, confronto {{match}} da arena. Seu adversário é {{target}}. Só um de vocês continuará. Agora, sua tarefa é criticar a solução do adversário.

=== TAREFA (idêntica para todos os concorrentes) ===
{{task}}
=== FIM DA TAREFA ===

Use seu cartão de estratégia como lente para encontrar falhas:
Modo de raciocínio: {{reasoning_name}}. {{reasoning_how}}
Fluxo de trabalho: {{workflow_name}}. {{workflow_how}}
Estratégia: {{strategy_name}}. {{strategy_how}}

Leia a solução do adversário: {{target_solution}}
Você pode ler a sua para comparar: {{own_solution}}. Avalie a solução adversária pelo que ela entrega em relação à tarefa, não por ser diferente da sua.

Encontre problemas reais:
- ERRADO: erros factuais ou lógicos, bugs e afirmações falsas.
- FALTANDO: requisito expresso na tarefa que foi ignorado ou atendido só em parte. Cite o requisito.
- FALHA: dado, cenário ou caso-limite concreto em que a solução não funciona. Dê o contraexemplo exato.
- VAGO: trecho que exige que a pessoa adivinhe o que fazer.

Regras:
- Cada crítica deve ser específica e verificável: indique o trecho exato, o problema e o motivo.
- Não elogie, não resuma e não faça críticas de estilo, a menos que impeçam o uso da solução.
- Não invente requisitos nem critique a abordagem; critique apenas erros concretos.
- Faça no máximo 7 críticas, começando pelas mais graves. Se encontrar só 2 problemas reais, registre apenas 2.
- Classifique cada crítica como FATAL (incorreta ou inutilizável para a tarefa), MAJOR (lacuna real) ou MINOR.
- Não crie, edite ou exclua nenhum arquivo além do indicado abaixo.

Grave as críticas em {{out}} neste formato:
ATTACK 1 [FATAL|MAJOR|MINOR] <título de uma linha>
Onde: <trecho ou localização>
Problema: <o que está errado, com contraexemplo ou requisito esquecido>
(repita o formato para as críticas seguintes)

Depois de gravar o arquivo, responda somente com esta linha:
ATTACKED {{target}} <número de críticas> (<quantas são FATAL> fatais)
```
<!-- /template:attacker -->

### Defensor, em cada rodada

<!-- template:defender -->
```text
Você é o concorrente {{agent}} na rodada {{round}}, confronto {{match}} da arena. Seu adversário {{attacker}} criticou sua solução. Agora, defenda-a e faça uma revisão. O juiz avaliará a versão revisada em relação à do adversário, incluindo como cada um lidou com as críticas recebidas.

=== TAREFA (idêntica para todos os concorrentes) ===
{{task}}
=== FIM DA TAREFA ===

Mantenha sua abordagem; foi ela que permitiu que você chegasse até aqui.
Modo de raciocínio: {{reasoning_name}}. {{reasoning_how}}
Fluxo de trabalho: {{workflow_name}}. {{workflow_how}}
Estratégia: {{strategy_name}}. {{strategy_how}}

Sua solução atual: {{own_solution}}
Críticas recebidas: {{attacks}}

Faça o seguinte:
1. Analise cada crítica com honestidade. CONCEDA se estiver correta e corrija o problema. REBATA se estiver errada e demonstre o motivo com evidências da tarefa, da solução ou de uma verificação concreta. Insistir que está certo sem evidências conta como concessão. Reconhecer e corrigir uma falha real vale mais do que defendê-la.
2. Escreva a solução revisada completa e independente, corrigindo todos os pontos concedidos. O juiz lerá apenas esse arquivo; não escreva “veja a versão anterior”. Não mencione a arena nem o cartão.
3. Corrija os pontos criticados e outros problemas que perceber durante a revisão. Não recomece do zero nem copie a solução do adversário.
4. Se o arquivo de críticas estiver vazio ou contiver NO OUTPUT, significa que você não foi criticado. Registre NO ATTACKS RECEIVED como defesa e envie sua solução novamente, com apenas as correções que já sabe que são necessárias.
5. Não crie, edite nem exclua nada fora de {{arena_dir}}.

Grave sua defesa ponto a ponto em {{defense_out}} neste formato:
ATTACK 1: CONCEDE|REBUT. <uma a três linhas>
(uma entrada por crítica)

Grave sua solução revisada em {{solution_out}}.

Depois de gravar os dois arquivos, responda somente com esta linha:
DEFENDED {{agent}} concedeu <n> rebateu <n>
```
<!-- /template:defender -->

### Juiz, em cada confronto

<!-- template:judge -->
```text
Você é o juiz do confronto {{match}}, rodada {{round}} da arena. Duas soluções para a mesma tarefa foram disputadas: cada uma criticou a outra e depois defendeu e revisou a si própria. Avalie ambas com a rubrica. A solução com a maior pontuação ponderada avança; a outra é eliminada.

=== TAREFA (idêntica para todos os concorrentes) ===
{{task}}
=== FIM DA TAREFA ===

Leia primeiro a rubrica: {{rubric}}

Solução {{first}}
- solução revisada: {{first_solution}}
- críticas recebidas: {{first_attacks}}
- defesa: {{first_defense}}

Solução {{second}}
- solução revisada: {{second_solution}}
- críticas recebidas: {{second_attacks}}
- defesa: {{second_defense}}

Como julgar:
1. Leia as duas soluções revisadas por completo antes de pontuar qualquer uma.
2. Confira cada crítica na solução revisada e classifique-a como FIXED, REBUTTED (somente se a resposta estiver correta) ou STANDING. Dizer “corrigido” não é prova; confira.
3. Procure também falhas que os atacantes não perceberam.
4. Dê nota de 0 a 10 para cada critério, seguindo as referências da rubrica. Marque fatal como true somente quando tiver verificado uma falha que torne a solução incorreta ou inutilizável para a tarefa.
5. Vence a maior pontuação ponderada, conforme os pesos da rubrica. Uma solução fatal não pode vencer uma solução não fatal. Em caso de empate exato, vence a que tiver menos críticas ainda procedentes; persistindo o empate, vence a de maior correção.
6. Avalie o trabalho, não o discurso sobre o trabalho. Extensão não é qualidade. Você não conhece os cartões de estratégia e não deve tentar adivinhá-los.
7. Não crie, edite ou exclua arquivo algum além do veredito. Se a tarefa envolver código e executar algo ajudar a resolver uma crítica, faça isso somente em {{arena_dir}}/scratch/judge-{{match}}/, nunca no projeto da pessoa.

Grave somente este JSON em {{out}}:
{
  "match": "{{match}}",
  "scores": {
    "{{first}}": {"correctness": 0, "completeness": 0, "specificity": 0, "robustness": 0, "clarity": 0, "fatal": false},
    "{{second}}": {"correctness": 0, "completeness": 0, "specificity": 0, "robustness": 0, "clarity": 0, "fatal": false}
  },
  "winner": "{{first}} or {{second}}",
  "reason": "uma frase: diferença decisiva",
  "survived": ["cada crítica enfrentada e superada pelo vencedor, em poucas palavras"],
  "standing": {"{{first}}": ["críticas ainda procedentes"], "{{second}}": ["críticas ainda procedentes"]}
}

Depois de gravar o arquivo, responda somente com esta linha:
WINNER <id do vencedor> <pontuação do vencedor>-<pontuação do eliminado>
```
<!-- /template:judge -->

### Avaliação final, somente quando houver uma resposta anterior

<!-- template:final -->
```text
Você é o juiz da avaliação final da arena. {{n}} concorrentes disputaram uma tarefa e uma solução sobreviveu a {{rounds}} rodadas. Antes de devolver o resultado à pessoa, compare-o à resposta que ela já havia rejeitado. Você não sabe qual solução é qual. Avalie apenas o que está diante de você. Qualquer uma pode vencer.

=== TAREFA ===
{{task}}
=== FIM DA TAREFA ===

Leia primeiro a rubrica: {{rubric}}

Solução X: {{x_solution}}
Solução Y: {{y_solution}}

Como julgar:
1. Leia as duas soluções completas antes de pontuar qualquer uma.
2. Critique as duas: encontre as falhas concretas mais importantes em cada uma, como faria uma pessoa especialista e rigorosa. Na nota de robustez, avalie quanto cada solução resiste a essas críticas.
3. Dê nota de 0 a 10 para cada critério, seguindo as referências da rubrica. Marque fatal como true somente quando tiver verificado uma falha que torne a solução incorreta ou inutilizável para a tarefa.
4. Vence a maior pontuação ponderada. Uma solução fatal não pode vencer uma não fatal.
5. Avalie o trabalho, não o discurso sobre o trabalho. Extensão não é qualidade.
6. Não crie, edite ou exclua arquivo algum além do veredito.

Grave somente este JSON em {{out}}:
{
  "scores": {
    "X": {"correctness": 0, "completeness": 0, "specificity": 0, "robustness": 0, "clarity": 0, "fatal": false},
    "Y": {"correctness": 0, "completeness": 0, "specificity": 0, "robustness": 0, "clarity": 0, "fatal": false}
  },
  "winner": "X or Y",
  "reason": "uma frase: diferença decisiva",
  "fixed": ["cada ponto que o vencedor resolveu corretamente e o outro não, em poucas palavras"]
}

Depois de gravar o arquivo, responda somente com esta linha:
FINAL <X ou Y> <pontuação de X>-<pontuação de Y>
```
<!-- /template:final -->

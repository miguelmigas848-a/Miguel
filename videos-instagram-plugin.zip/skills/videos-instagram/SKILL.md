---
name: videos-instagram
description: >-
  Planeje, corte, edite e renderize vídeos verticais para Instagram, incluindo Reels, gravações faladas, legendas, animações e motion graphics. Use ao criar ou adaptar vídeos com Remotion, HyperFrames ou o fluxo VSL de edição. Escolha o método adequado ao material e aos recursos disponíveis. Responda em português brasileiro; preserve URLs, comandos, nomes de pacotes e identificadores técnicos.
---

# Vídeos para Instagram

Skill unificada para planejar, editar, animar e revisar vídeos destinados ao Instagram. O fluxo principal escolhe o método de produção conforme o material enviado e os recursos disponíveis; as referências de Reel, Remotion e HyperFrames detalham cada caminho.

## Quando usar

Use para criar ou editar Reels e outros vídeos verticais, cortar uma gravação falada, montar legendas, fazer motion graphics, adaptar uma composição Remotion/HyperFrames ou preparar um vídeo para publicação no Instagram. Não use como catálogo estático de provedores de API ou como instrução para instalar plugins.

## Regras de trabalho

- Converse e escreva os textos do vídeo em português brasileiro, salvo pedido diferente. Preserve URLs, comandos, nomes de pacotes, identificadores de código e citações técnicas.
- Trate os arquivos da pessoa como originais: trabalhe em cópias dentro de uma pasta própria do projeto e não sobrescreva o vídeo bruto.
- Não publique, envie, agende nem compartilhe o vídeo sem pedido explícito.
- Não invente dados, depoimentos, logotipos, telas de produto ou resultados. Use recursos reais fornecidos pela pessoa ou imagens de fontes confiáveis; registre origem e licença quando usar material externo.
- Antes de baixar ferramentas ou instalar dependências, confira o que já está disponível. Não instale plugin de agente nem inclua manifesto de plugin para usar esta skill.
- Não suponha que Claude Cloud ou ChatGPT tenham terminal, Node.js, Python, FFmpeg, Chromium, memória persistente ou conexão externa habilitados. Confirme as ferramentas expostas no ambiente e adapte o fluxo. Se não houver renderizador, entregue o projeto editável ou explique com precisão o que falta para renderizar.
- Não use serviços pagos, créditos de API, geração de avatar ou renderização em nuvem sem autorização clara para o custo.

## Escolha o fluxo certo

| Material ou pedido | Fluxo |
| --- | --- |
| Gravação falada para Reel: selecionar falas, cortar pausas/erros, editar com legenda e peças animadas | Leia `FLUXO-REEL.md` e siga `regras-da-casa.md`, `corte/CORTE.md` e `modelo/README.md`. |
| Animação React, introdução, títulos, transições, legendas ou motion graphics | Leia `remotion/FLUXO-REMOTION.md`, depois `remotion/references/motion-patterns.md` e `remotion/references/design-rules.md`. |
| Projeto existente em HyperFrames, edição de timeline HTML/GSAP ou importação de uma animação | Leia `referencias/HYPERFRAMES.md`; consulte a ajuda da versão de CLI instalada antes de executar comandos. |
| Integração de API para gerar mídia, texto ou narração | Leia `referencias/INTEGRACAO-IA.md`. Use os catálogos incorporados apenas como referências e confirme os termos atuais na documentação oficial do provedor. |

Não misture motores por padrão. Escolha um fluxo principal e só importe outra tecnologia quando isso resolver uma necessidade concreta, como manter a edição da timeline ou reaproveitar uma animação existente.

## Fluxo de produção

### 1. Defina o resultado

Confirme o objetivo, o público, a ação final desejada, o material de origem, o estilo da marca, a duração aproximada, o formato e se a pessoa quer um roteiro, projeto editável, prévia ou arquivo renderizado. Para um Reel sem outras instruções, comece em 9:16. Confirme as especificações atuais do Instagram em fonte oficial quando o tamanho, codec, duração ou limite de upload for decisivo.

Se a pessoa pedir para continuar um estilo anterior, consulte uma memória persistente somente se uma ferramenta de memória estiver realmente disponível e o escopo estiver autorizado. Cite a evidência encontrada. Se não houver conexão, diga isso; nunca invente preferências recuperadas.

### 2. Planeje a narrativa

Para vídeo falado, preserve o sentido e a voz da pessoa. Remova pausas, retomadas e erros somente quando a edição não cortar palavras nem alterar o significado. Organize o Reel em gancho, contexto, desenvolvimento, recompensa e uma chamada para ação. Não acrescente afirmações que não estejam no material original ou em fontes verificáveis.

Para comparar ideias, crie três propostas com enfoques distintos apenas quando isso ajudar a escolha. Use a rubrica em `referencias/REVISAO-CRIATIVA.md`; explique as notas e escolha a versão mais clara e fiel. Uma revisão sequencial não deve ser apresentada como disputa multiagente. Use o auxiliar Arena somente se a pessoa pedir uma arena e o ambiente realmente oferecer ferramentas de delegação.

### 3. Produza com o método escolhido

- **Fluxo Reel/VSL:** crie uma pasta exclusiva para o trabalho; confira as dependências com `corte/scripts/0-checar.py`; leia a transcrição e o mapa de tomadas; corte e confira cada emenda; corrija as palavras sem correspondência antes de montar o vídeo. Siga a ordem detalhada em `FLUXO-REEL.md`.
- **Remotion:** mantenha um único objeto de tema; derive o tempo de `fps`; use easing e entradas escalonadas; mantenha texto na zona segura; renderize e inspecione quadros. Copie `remotion/assets/theme.ts` para o projeto somente quando for usar esse fluxo.
- **HyperFrames:** preserve a edição em cenas e timeline, use o CLI já instalado e consulte `referencias/HYPERFRAMES.md`. Não faça captura de sites, chamadas a provedores ou instalações sem necessidade e autorização.

Em qualquer fluxo, mantenha o rosto e a fala compreensíveis; não cubra a boca com legendas ou elementos gráficos. Sincronize as legendas com a fala, aplique contraste legível e evite texto encostado nas bordas ou encoberto pela interface do Instagram.

### 4. Confira a montagem

Antes da entrega, verifique:

- gancho claro nos primeiros segundos e uma ideia principal por vídeo;
- nenhum corte come palavras, sílabas ou respirações necessárias;
- legendas fiéis ao áudio, legíveis e dentro da zona segura;
- textos, logotipos e telas corretos, com origem verificável;
- ritmo variado, entradas escalonadas e pausas intencionais;
- música e efeitos em volume adequado, sem competir com a voz;
- nenhum quadro preto, elemento cortado, camada fora de ordem ou animação parada involuntária;
- proporção, resolução, taxa de quadros, duração e codec conforme as exigências atuais do destino;
- renderização não vazia, duração coerente com a composição e inspeção visual de quadros iniciais, médios, finais e de cada transição importante.

Se houver problema, corrija, renderize novamente e reinspecione. Não declare que o vídeo foi verificado se não foi possível abrir ou inspecionar a renderização.

### 5. Entregue

Entregue o arquivo final e, se solicitado ou útil, o projeto editável. Informe o nome, o formato, a duração e quais verificações foram concluídas. Não publique o arquivo. Se alguma ferramenta ou dependência não estava disponível, diga qual etapa não pôde ser concluída e o caminho prático para terminá-la.

## Referências integradas

- `FLUXO-REEL.md` e os diretórios `corte/`, `modelo/` e `ferramentas/`: edição de gravações faladas, exemplos, scripts, fontes e efeitos sonoros.
- `remotion/`: fluxo Remotion traduzido, padrões de movimento, regras de design e tema.
- `referencias/HYPERFRAMES.md`: criação/editabilidade, mídia, CLI, prévia, inspeção de quadros e renderização em HyperFrames.
- `referencias/REVISAO-CRIATIVA.md`: comparação de propostas com critérios visuais e editoriais.
- `referencias/INTEGRACAO-IA.md` e `fontes-ia/central-de-apis-llm-gratuitas/`: uso seguro e contextual de provedores de IA; os números e ofertas dos catálogos podem estar desatualizados.
- `referencias/CONSULTA-DE-MEMORIA.md`: como consultar memórias apenas quando a integração estiver disponível.
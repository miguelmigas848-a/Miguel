# Fontes e decisões de consolidação

Este pacote reúne material de vídeo, edição e referências auxiliares em uma única skill com o nome `videos-instagram`. Os ZIPs e arquivos `.skill` originais permanecem intactos na pasta de origem.

## Material incorporado

- **Reel/VSL:** foi usada a versão `reel-skill-ptbr.zip`, que contém o fluxo em português e os recursos de corte, exemplos, kit, fontes, mídia e ferramentas. As outras cópias de `skill-reel-main` compartilham os mesmos arquivos de apoio e foram deduplicadas. O manifesto original foi integrado ao `SKILL.md` único; seu conteúdo detalhado está em `FLUXO-REEL.md`.
- **Remotion:** os três arquivos `.skill` de origem eram idênticos. Foram incorporados os recursos e o fluxo em português do ZIP `remotion-motion-graphics-pt-br.zip`.
- **APIs e catálogos:** `fontes-ia/central-de-apis-llm-gratuitas/` mantém o pacote consolidado em português e os arquivos originais extraídos, que já reúnem `free-llm-api-keys`, `awesome-claude-skills`, `awesome-freellm-apis` e `FreeLLM-API-KeyHub`. As instruções da skill estão em PT-BR; alguns documentos brutos de referência mantêm os idiomas de origem, com referências traduzidas em `referencias/pt-BR/`. O manifesto foi convertido em referência e as instruções alertam que cotas e ofertas podem mudar.
- **Arena e memória:** o método de avaliação foi adaptado para revisão criativa de vídeos. Os arquivos auxiliares de Arena sem manifestos de plugin estão em `fontes/arena/`; a consulta de memória foi integrada como opção que só funciona se houver uma ferramenta conectada.
- **HyperFrames:** os fluxos de CLI, edição, mídia, catálogo, importação de Remotion, prévia e revisão foram resumidos em `referencias/HYPERFRAMES.md`. O repositório completo (`hyperframes-main.zip`) tem cerca de 150 MB e milhares de arquivos; o plugin tem várias skills e manifestos. Embuti-los reproduziria os erros de limite, ZIP aninhado e manifesto. Os links principais estão em `referencias/FONTES-HYPERFRAMES.md`.

## Erros de pacote eliminados

O ZIP final tem uma pasta de skill na raiz, um único arquivo chamado `SKILL.md`, nenhum manifesto de plugin e nenhum ZIP aninhado. As skills auxiliares dos pacotes Arena, Memória, APIs, Reel e Remotion foram mescladas ou renomeadas como referências, evitando manifestos duplicados.

# Guia do pacote — Vídeos para Instagram

Este ZIP é uma única skill no formato Agent Skills. Envie o mesmo arquivo pela opção de upload na área Skills do ChatGPT e do Claude. No ChatGPT, o caminho documentado é **Skills → Criar → Carregar do computador**. No Claude, use a área de Skills nas configurações. A disponibilidade depende do plano e das configurações da conta; o uso de scripts exige execução de código habilitada.

O pacote tem uma pasta na raiz e um único arquivo `SKILL.md`. As referências, exemplos e ferramentas de apoio ficam ao lado dele. Não há ZIP interno nem manifesto de plugin.

As instruções operacionais estão em português brasileiro e combinam os fluxos de edição de fala/Reel, Remotion e HyperFrames. O material auxiliar de APIs mantém alguns documentos nos idiomas originais; há referências em português na pasta `fontes-ia/central-de-apis-llm-gratuitas/referencias/pt-BR/`. Os originais enviados permanecem intactos fora deste pacote. Consulte `FONTES.md` para ver como os conteúdos foram integrados e por que o repositório HyperFrames completo não está embutido.

Disponibilidade de terminal, ferramentas de renderização, permissões e verificação de segurança depende da conta e do ambiente. Ative a skill e confirme se a execução de código está habilitada na plataforma escolhida.

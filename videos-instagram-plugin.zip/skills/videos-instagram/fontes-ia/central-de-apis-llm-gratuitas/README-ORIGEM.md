> Referência do pacote de APIs de origem. Para instalar e usar a skill unificada de vídeos, use o `README.md` e o `SKILL.md` na raiz deste ZIP.

# Central de APIs de LLM gratuitas — português brasileiro

Este pacote reúne os conteúdos extraídos de cinco arquivos ZIP em uma única Skill. Inclui diretórios de APIs e chaves gratuitas ou promocionais, exemplos de configuração e um catálogo de Skills do Claude.

## Instalação

Envie este ZIP pela área de Skills do ChatGPT ou Claude. O arquivo contém uma pasta da Skill na raiz, um único SKILL.md e as referências de apoio. A disponibilidade depende dos recursos habilitados em cada produto, plano e espaço de trabalho.

## Conteúdo

- SKILL.md: instruções e metadados da Skill.
- referencias/pt-BR/: guias e referências em português brasileiro.
- fontes/originais/: arquivos extraídos dos projetos originais, preservados sem alteração.

Os arquivos ZIP de origem não ficam aninhados no pacote porque o importador de Skills os rejeita. Seus arquivos extraídos estão preservados. Os dois ZIPs awesome-claude-skills são idênticos; o conteúdo extraído deles aparece uma vez para evitar duplicatas.

## Uso recomendado

Peça, por exemplo: “Compare provedores de API gratuitos compatíveis com OpenAI”, “Monte uma configuração do Codex CLI com placeholders” ou “Encontre uma Skill para trabalhar com PDF”. A Skill responde em português brasileiro, mantém links e identificadores técnicos e recomenda conferir preços e cotas nas páginas oficiais.

As listas de provedores são referências fornecidas nos arquivos de origem, não uma garantia de disponibilidade atual. O pacote não contém chaves de API funcionais.

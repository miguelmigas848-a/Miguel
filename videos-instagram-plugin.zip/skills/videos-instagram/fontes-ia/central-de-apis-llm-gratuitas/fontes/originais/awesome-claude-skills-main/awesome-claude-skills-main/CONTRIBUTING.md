# Contributing to Awesome Claude Skills

Thank you for your interest in contributing to Awesome Claude Skills! This document provides guidelines for contributing to this list.

> [!NOTE]
> Given the growth in assisted skill development, a new requirement of "social proof" has been added to skill submissions.

## How to Contribute

1. **Fork the repository** - Click the "Fork" button in the top right corner
2. **Create a branch** - Create a new branch for your contribution
3. **Make your changes** - Add your skill, resource, or improvement
4. **Submit a pull request** - Open a PR with a clear description of your changes

## What to Contribute

We welcome contributions in the following categories:

### Skills

- Official skills from Anthropic
- Community-created skills
- Your own custom skills

### Resources

- Documentation
- Tutorials and guides
- Blog posts and articles
- Videos and presentations
- Tools and utilities

### Improvements

- Fixing typos or broken links
- Improving descriptions
- Reorganizing content for better clarity
- Adding missing information

## Guidelines

### Quality Standards

All contributions should:

- Be related to Claude Skills
- Provide clear value to users
- **Be non-promotional (see below)**
- Include accurate, up-to-date information
- Use proper formatting and grammar

### No Promotions or Commercial Segues

This list is a community resource, not a marketing channel. We strictly filter out submissions that serve primarily as a funnel for commercial products.

- **No "SaaS Wrappers":** Skills that exist solely to call a specific commercial API or require a paid subscription to a specific SaaS platform (especially one owned by the submitter) to function are generally not accepted.
- **Standalone Value:** Submissions must provide value on their own. If the content is clearly just a segue to a paid product, it will be rejected.
- **Genuine Resources:** Tutorials and articles must focus on education, not conversion. "Teaser" content designed to upsell a course or tool will not be merged.

### Formatting

When adding a new item:

```markdown
- **[Name](link)** - Clear, concise description of what it does

```

Examples:

```markdown
- **[pdf-analyzer](https://github.com/username/pdf-analyzer)** - Advanced PDF analysis skill with OCR support
- **[Claude Skills Tutorial](https://example.com/tutorial)** - Step-by-step guide to creating your first skill

```

#### Adding an individual skill

Add a row to the individual skills table using the same pattern as the other rows.

### Skill Submissions

When submitting a skill, please include:

* Clear name and link to the skill repository
* Brief description (1-2 sentences) of what it does
* Any prerequisites or dependencies
* License information (if applicable)

The skill should:

* Have a clear purpose and use case
* Include documentation (README or SKILL.md)
* Follow Claude Skills best practices
* Be functional and tested

Above all else, the skill should be a value-add. Trivial functionalities that were whipped up with a session or two with Claude Code are not likely to be worthwhile skills for community members to make use of almost by definition (i.e. if the skill could be created that quickly, it would probably be something an individual would implement by themselves to match their own particular use case).

While not an absolute requirement, a strong general guideline would be that more exists to the skill than a single `SKILL.md` file. 

#### Social Proof

Skills must have gathered enough attention from the community so-as to have acquired a number of GitHub stars to be considered in most cases. 

*This is due to the increase in PR submissions of either newly completed and untested skills or narrow-focused and not generalizable skills that simply do not make sense in a GitHub Awesome list meant to appeal to a wide audience.*

> [!NOTE]
> Due to the volume of PR submissions that do not conform to these contribution guidelines, if your skill hasn't acquired a basic 10 stars, it will be closed automatically.

#### AI Automated Submissions

Due to the influx of PRs, there is a requirement now that the PR not be explicitly generated / submitted with AI-assistance. 

It's too untenable to try and review the entire codebase of an LLM-generated project that was also submitted with the help of generative AI. This requirement is intended to serve as a quick filter (which is honestly surprising, given that AI coding assistants are easily capable of ingesting the language of a `CONTRIBUTING.md` file of a repository).

PRs will be closed without comment if the submitter has failed to acknowledge this or adhere by its basic tenets in order to weed out the low-effort submissions. 

#### SaaS Submissions

If the skill you're submitting is based around a SaaS, it's unlikely to get reviewed and will be closed. 

This awesome list is not a jumping off point for your new venture — it's intended to be mostly for skills that improve the DX or UX of Claude / Claude Code without requiring requests going through your server.

### Article/Resource Submissions

When submitting articles or resources:

* Ensure the content is substantial and informative
* Include the title and a direct link
* Add a brief description
* Verify all links work correctly

## Categories

Place your contribution in the most appropriate category:

* **Official Resources** - Only official Anthropic content
* **Documentation** - Technical documentation and reference material
* **Official Skills** - Skills from anthropics/skills repository
* **Community Skills** - Skills created by the community
* **Tools & Utilities** - Development tools and utilities
* **Tutorials & Guides** - How-to guides and tutorials
* **Articles & Blog Posts** - Published articles and blog posts

If you're unsure which category fits best, place it where you think it belongs and mention it in your PR description.

## Pull Request Process

1. **Search existing PRs** - Check if someone else has already submitted something similar
2. **One item per PR** - Submit one skill/resource per pull request (unless they're closely related)
3. **Clear title** - Use a descriptive PR title like "Add PDF analysis skill" or "Add tutorial on creating custom skills"
4. **Description** - Explain what you're adding and why it's valuable
5. **Test links** - Ensure all links work before submitting
6. **Follow the format** - Match the existing style and structure

### PR Title Examples

* ✅ `Add custom SQL query skill`
* ✅ `Add tutorial: Building your first Claude Skill`
* ✅ `Fix broken link in Documentation section`
* ❌ `Update README` (too vague)
* ❌ `Add stuff` (not descriptive)

## Code of Conduct

By contributing, you agree to:

* Be respectful and inclusive
* Provide constructive feedback
* Focus on what is best for the community
* Show empathy towards other community members

## Questions?

If you have questions about contributing:

* Open an issue with your question
* Check existing issues to see if it's already been answered
* Review the [Awesome list guidelines](https://github.com/sindresorhus/awesome/blob/main/contributing.md)

<p align="center">
  <h1 align="center">Free LLM API Keys — Get Free API Keys for Every LLM</h1>
  <p align="center"><strong>The complete directory of free LLM API keys</strong> — Groq, Google Gemini, Mistral, Cohere, NVIDIA NIM, OpenRouter, and 25+ more providers.</p>
</p>

<p align="center">
  <a href="http://freellms.org/" target="_blank" rel="noopener"><strong>🌐 Visit freellms.org for the full live directory</strong></a>
</p>

---

## What is this?

A curated, always-up-to-date list of **free LLM API keys** — where to get them, what they unlock, and how to use them. No trial credits, no expiring allowances. Just permanently free API keys you can grab in under a minute.

Every key listed here works with OpenAI-compatible tooling (Cursor, Codex CLI, Claude Code, Aider, Cline, Open WebUI, and 10+ more).

> **Live, searchable directory:** <a href="http://freellms.org/" target="_blank" rel="noopener">freellms.org</a>

---

## Free API Key Directory

| Provider | Get Free API Key | Credit Card? | Free Tier |
|---|---|---|---|
| Groq | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | 30 RPM, 14,400 RPD |
| Google Gemini | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | 15 RPM, 1,500 RPD |
| Mistral AI | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | Free tier |
| Cohere | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | 20 RPM |
| NVIDIA NIM | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | Phone | 1M context |
| OpenRouter | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | Registration | 1K RPD |
| GitHub Models | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | Free tier |
| Cloudflare Workers AI | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | 10K neurons/day |
| Cerebras | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | 5 RPM |
| Hugging Face | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | Free tier |
| Z AI (Zhipu) | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | Free tier |
| SambaNova | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | Registration | 20 RPM |
| LLM7.io | <a href="http://freellms.org/" target="_blank" rel="noopener">Get Key →</a> | No | 30 RPM |

> **Full list of 30+ providers:** <a href="http://freellms.org/" target="_blank" rel="noopener">freellms.org</a>

---

## How to Get a Free API Key (3 Steps)

1. **Pick a provider** — start with **Groq** (no credit card, instant key).
2. **Sign up & copy your key** — most providers only need an email.
3. **Use it** — paste the key + base URL into any OpenAI-compatible tool.

Detailed walkthrough for each provider: <a href="http://freellms.org/" target="_blank" rel="noopener">freellms.org</a>

---

## Quick Start — Use Your Free API Key

### Python

```python
from openai import OpenAI

client = OpenAI(
    base_url="https://api.groq.com/openai/v1",  # free, no credit card
    api_key="YOUR_FREE_API_KEY",                 # get at freellms.org
)

response = client.chat.completions.create(
    model="llama-3.3-70b-versatile",
    messages=[{"role": "user", "content": "Hello!"}],
)
print(response.choices[0].message.content)
```

### Cursor / Codex / Claude Code

Step-by-step config for every major tool: <a href="http://freellms.org/" target="_blank" rel="noopener">freellms.org</a>

---

## Why use a free LLM API key?

- **No credit card** — most providers issue keys on email signup alone
- **No expiry** — permanently free tiers, not trial credits
- **OpenAI-compatible** — drop-in for any tool that accepts `baseURL` + `apiKey`
- **Production-usable** — generous rate limits for personal projects and prototyping

Browse all providers, compare rate limits, and grab your free API key at <a href="http://freellms.org/" target="_blank" rel="noopener">**freellms.org**</a>.

---

## Related Resources

- <a href="http://freellms.org/" target="_blank" rel="noopener">Free LLM API directory</a>
- <a href="http://freellms.org/" target="_blank" rel="noopener">Free OpenAI-compatible API list</a>
- <a href="http://freellms.org/" target="_blank" rel="noopener">Free AI proxy gateway</a>
- <a href="http://freellms.org/" target="_blank" rel="noopener">Free LLM models catalog</a>
- <a href="http://freellms.org/" target="_blank" rel="noopener">Awesome free AI agents</a>

## License

MIT — keys and links sourced from <a href="http://freellms.org/" target="_blank" rel="noopener">freellms.org</a>, updated daily.

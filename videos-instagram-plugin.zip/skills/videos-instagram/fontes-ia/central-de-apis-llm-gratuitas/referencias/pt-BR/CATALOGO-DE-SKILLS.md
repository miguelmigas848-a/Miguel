# Catálogo de Skills do Claude

O projeto awesome-claude-skills reúne links para Skills oficiais e comunitárias, ferramentas, documentação e tutoriais. Skills são pastas com instruções e recursos que ensinam um agente a executar tarefas de modo repetível. Os nomes de Skills e os endereços dos projetos são mantidos na forma original para permitir busca e instalação.

## Skills oficiais destacadas

### Documentos

- docx: criar, editar e analisar documentos Word, com alterações controladas, comentários, preservação de formatação e extração de texto.
- pdf: extrair texto e tabelas, criar, combinar e dividir PDFs e trabalhar com formulários.
- pptx: criar, editar e analisar apresentações PowerPoint, layouts, modelos, gráficos e automação de slides.
- xlsx: criar, editar e analisar planilhas, fórmulas, formatação, dados e visualizações.

### Design e criação

- algorithmic-art: criar arte generativa com p5.js, aleatoriedade reproduzível, campos de fluxo e partículas.
- canvas-design: criar arte visual em PNG e PDF com princípios de design.
- slack-gif-creator: criar GIFs animados adequados aos limites do Slack.

### Desenvolvimento e comunicação

- frontend-design: orientar decisões de interface para criar experiências marcantes em React e Tailwind.
- web-artifacts-builder: montar artefatos HTML para Claude.ai usando React, Tailwind e shadcn/ui.
- mcp-builder: orientar a criação de servidores MCP para integrar APIs externas.
- webapp-testing: testar aplicações web locais com Playwright.
- brand-guidelines: aplicar cores e tipografia oficiais de uma marca.
- internal-comms: redigir relatórios, boletins, perguntas frequentes e outras comunicações internas.
- skill-creator: orientar a criação de uma Skill por meio de perguntas e etapas.

## Projetos comunitários destacados

- obra/superpowers: biblioteca de Skills para Claude Code, incluindo brainstorming, planejamento, execução, testes e depuração.
- obra/superpowers-lab: técnicas experimentais para Claude Code.
- ios-simulator-skill: automatizar criação, navegação e testes de aplicativos iOS.
- ffuf-web-fuzzing: orientar fuzzing web com ffuf em testes autorizados.
- playwright-skill: automação de navegador com Playwright.
- claude-d3js-skill: visualizações com d3.js.
- claude-scientific-skills: Skills para bibliotecas e bases de dados científicas.
- web-asset-generator: gerar favicons, ícones de aplicativos e imagens para redes sociais.
- Trail of Bits Security Skills: análise estática, auditoria e identificação de vulnerabilidades.
- frontend-slides: criar apresentações HTML animadas ou converter arquivos PowerPoint.
- Expo Skills e shadcn/ui: desenvolvimento com ferramentas e componentes desses projetos.
- Skill_Seekers: converter sites de documentação em Skills.

Os links completos de cada projeto, mais tutoriais, recursos oficiais, guias de criação, solução de problemas e perguntas frequentes, permanecem no arquivo original em fontes/originais/awesome-claude-skills-main/awesome-claude-skills-main/README.md. Use aquele índice como catálogo de links e esta referência em português como guia de leitura.

## Criação e segurança

Uma Skill costuma ter um arquivo SKILL.md com metadados YAML, instruções claras e, opcionalmente, scripts ou recursos de apoio. Descrições concisas ajudam a encontrar a Skill certa. Exemplos, dependências e instruções de uso melhoram a manutenção.

Antes de instalar uma Skill comunitária, revise suas instruções e todos os scripts. Conceda somente permissões necessárias, mantenha o conteúdo sob controle de versão e teste em ambiente não produtivo. Uma Skill pode executar código ou conter instruções maliciosas. Confirme a disponibilidade de recursos e controles administrativos na documentação oficial atual.

# Provedores, cotas e ofertas

## Diretórios de API

O projeto awesome-free-llm-apis informa uma fotografia de 513+ APIs gratuitas de 30 provedores e oferece uma lista consultável em https://freellm.net, páginas de modelos em https://freellm.net/models/, playground em https://freellm.net/playground/, gerador de configuração em https://freellm.net/config/ e índice de chaves em https://freellm.net/free-llm-api-keys/. A cópia incluída registra atualização em 20/10/2026. Use a versão ao vivo para checar se a informação continua correta.

O índice diferencia provedores com cota gratuita permanente de provedores com créditos renováveis. A lista de origem inclui NVIDIA NIM, ModelScope, Cloudflare Workers AI, OpenCode Zen, LLM7.io, Kilo Code, Google Gemini, Ollama Cloud, Mistral AI, OVHcloud AI Endpoints, Groq, Cohere, Aion Labs, Hugging Face, Z AI, Cerebras, Agnes AI, Alibaba Cloud Model Studio, Cline, SiliconFlow, SambaNova, xAI, Chutes.ai, Glhf.chat, AI21 Labs, DeepSeek, Nscale, Nebius e OpenRouter. A cobertura e os limites podem mudar.

Para links diretos de chaves e URLs-base, use a referência original em fontes/originais/awesome-freellm-apis-main/awesome-freellm-apis-main/README.md. Ela inclui os endpoints e links de cadastro do catálogo. Os exemplos adicionais estão na pasta code-examples.

## Lista de chaves gratuitas

O projeto free-llm-api-keys reúne links de cadastro e exemplos para Groq, Google Gemini, Mistral AI, Cohere, NVIDIA NIM, OpenRouter, GitHub Models, Cloudflare Workers AI, Cerebras, Hugging Face, Z AI, SambaNova e LLM7.io, entre outros. Consulte a tradução do README em CHAVES-DE-API-LEIA-ME.md. O site associado é http://freellms.org/. A tabela original cita, entre outros exemplos, Groq: 30 RPM e 14.400 RPD; Google Gemini: 15 RPM e 1.500 RPD; Cohere: 20 RPM; e cotas gratuitas para outros provedores. RPM e RPD significam solicitações por minuto e por dia. Confirme sempre os limites vigentes.

## Catálogo FreeLLM-API-KeyHub

A fonte organiza provedores em duas partes: créditos/uso promocional para chamadas de API e planos de programação. Os campos originais foram: nome da plataforma, benefício de cadastro, validade, convite ou indicação, benefício estudantil, pré-requisito e observações. As ofertas citadas incluem créditos de SiliconFlow, Volcengine Ark, Z AI/GLM, LongCat, Alibaba Cloud Model Studio, Baidu, Tencent Hunyuan, MiniMax, Kimi, PPIO, DeepSeek, iFlytek Spark, StreamLake, China Telecom, SenseNova, DMXAPI, 01.AI, China Mobile MoMA, DataEye, Kunlun, 360, Yunzhisheng e outros provedores internacionais.

O catálogo também lista planos ou pacotes de programação de GLM, Alibaba Cloud Model Studio, Volcengine Ark, MiniMax, Moore Threads, Tencent Hunyuan, iFlytek Spark e LongCat. Para preservar os detalhes e os links de cada oferta, consulte o README e a tabela completa LLM_API_Providers_All.md em fontes/originais/FreeLLM-API-KeyHub-main/FreeLLM-API-KeyHub-main/. O projeto afirma que não distribui chaves de API; reúne informações públicas.

### Índice integral de provedores do KeyHub

Os nomes abaixo cobrem os 47 registros da seção de créditos e ofertas do README de origem. Os nomes de marca foram mantidos para que possam ser localizados nos portais e arquivos originais:

1. SiliconFlow
2. Volcengine Ark
3. Zhipu AI (GLM)
4. Meituan (LongCat)
5. Alibaba Cloud Model Studio (Bailian)
6. Baidu AI Cloud (Qianfan)
7. Tencent Cloud Hunyuan
8. MiniMax
9. Kimi Open Platform (Moonshot AI)
10. PPIO
11. DeepSeek
12. iFlytek Spark
13. StreamLake (Kuaishou)
14. China Telecom (Tianyi AI)
15. SenseTime (SenseNova)
16. DMXAPI
17. 01.AI
18. China Mobile MoMA
19. DataEye
20. Kunlun Tech
21. 360 AI Brain
22. Unisound (Shanhai)
23. AWS Bedrock
24. Anyscale
25. NCompass
26. DigitalOcean GenAI
27. Google AI Studio
28. NVIDIA NIM
29. AI21 Labs
30. Anthropic
31. Mistral AI
32. Modal
33. BaseTen
34. BentoCloud
35. Cohere
36. InceptionLabs
37. Jina AI
38. Cerebras
39. Groq
40. OpenRouter
41. Inference.net
42. Mara
43. Poolside
44. IBM watsonx
45. Morph Labs
46. Relace
47. Mancer

### Índice integral de planos de programação

O README também compara estes oito planos/pacotes: Zhipu AI GLM Coding Plan; Alibaba Cloud Model Studio Coding Plan; Volcengine Ark Coding Plan; MiniMax Token Plan; Moore Threads AI Coding Plan; Tencent Cloud Hunyuan Token Plan; iFlytek Spark Coding Plan; e pacote de tokens Meituan LongCat. Os valores, bônus, limites e modelos permanecem nos documentos de origem intactos e devem ser confirmados nas páginas oficiais antes do uso.

## Como interpretar “gratuito”

- **Cota permanente:** o provedor descreve uma franquia gratuita contínua, sujeita a limites e termos.
- **Crédito promocional:** saldo inicial, convite ou campanha; pode expirar.
- **Plano de programação:** assinatura ou pacote para uso de ferramentas de código; pode ser pago e ter limites de solicitações ou tokens.
- **Sem cartão:** não significa ausência de cadastro, verificação por telefone, limite de uso ou coleta de dados.
- **Compatível com OpenAI:** indica semelhança de interface; não garante compatibilidade total com modelos, ferramentas ou parâmetros.

## Ferramentas de agregação citadas nas fontes

Os materiais citam One-API e New-API para encaminhar ou administrar APIs de vários provedores. Isso envolve configuração adicional e gestão segura de credenciais. Confira os repositórios originais antes de instalar.

# Chaves gratuitas de API para LLMs

Diretório completo de chaves gratuitas de API para LLMs — Groq, Google Gemini, Mistral, Cohere, NVIDIA NIM, OpenRouter e mais de 25 provedores.

[🌐 Acesse freellms.org para consultar o diretório atualizado](http://freellms.org/)

## O que é este recurso?

Uma lista organizada de APIs de LLM gratuitas: onde obter uma chave, o que cada serviço oferece e como usá-la. A fonte original afirma que há cotas gratuitas sem expiração e sem créditos de teste; confirme sempre os termos atuais de cada provedor.

As chaves listadas são apresentadas como compatíveis com ferramentas que aceitam endpoints compatíveis com OpenAI, como Cursor, Codex CLI, Claude Code, Aider, Cline e Open WebUI.

**Diretório ao vivo e pesquisável:** [freellms.org](http://freellms.org/)

## Diretório de chaves gratuitas

| Provedor | Obter chave gratuita | Cartão de crédito? | Cota gratuita citada na fonte |
|---|---|---|---|
| Groq | [Obter chave](http://freellms.org/) | Não | 30 RPM, 14.400 RPD |
| Google Gemini | [Obter chave](http://freellms.org/) | Não | 15 RPM, 1.500 RPD |
| Mistral AI | [Obter chave](http://freellms.org/) | Não | Plano gratuito |
| Cohere | [Obter chave](http://freellms.org/) | Não | 20 RPM |
| NVIDIA NIM | [Obter chave](http://freellms.org/) | Telefone | Contexto de 1M |
| OpenRouter | [Obter chave](http://freellms.org/) | Cadastro | 1K RPD |
| GitHub Models | [Obter chave](http://freellms.org/) | Não | Plano gratuito |
| Cloudflare Workers AI | [Obter chave](http://freellms.org/) | Não | 10 mil neurônios/dia |
| Cerebras | [Obter chave](http://freellms.org/) | Não | 5 RPM |
| Hugging Face | [Obter chave](http://freellms.org/) | Não | Plano gratuito |
| Z AI (Zhipu) | [Obter chave](http://freellms.org/) | Não | Plano gratuito |
| SambaNova | [Obter chave](http://freellms.org/) | Cadastro | 20 RPM |
| LLM7.io | [Obter chave](http://freellms.org/) | Não | 30 RPM |

**Lista completa com mais de 30 provedores:** [freellms.org](http://freellms.org/)

## Como obter uma chave de API gratuita

1. **Escolha um provedor.** A fonte sugere começar pelo Groq, que lista cadastro sem cartão e geração de chave imediata.
2. **Cadastre-se e copie sua chave.** Muitos provedores aceitam cadastro por e-mail.
3. **Configure a ferramenta.** Informe a chave e a URL-base no cliente compatível.

O passo a passo específico de cada provedor está em [freellms.org](http://freellms.org/).

## Início rápido com Python

    from openai import OpenAI

    client = OpenAI(
        base_url="https://api.groq.com/openai/v1",  # endpoint do exemplo
        api_key="SUA_CHAVE_DE_API",                 # obtenha no freellms.org
    )

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": "Olá!"}],
    )
    print(response.choices[0].message.content)

O trecho mantém nomes de campos e chamadas do SDK. Use uma variável de ambiente ou armazenamento seguro em vez de gravar uma chave real no código.

## Cursor, Codex e Claude Code

As instruções de configuração para ferramentas populares estão em [freellms.org](http://freellms.org/).

## Por que usar uma API gratuita de LLM?

- **Sem cartão de crédito:** a fonte informa que muitos provedores liberam chaves após cadastro por e-mail.
- **Sem expiração:** algumas cotas são apresentadas como permanentes, e não como créditos de teste.
- **Compatibilidade com OpenAI:** a interface pode aceitar configurações equivalentes a baseURL e apiKey.
- **Uso em projetos e protótipos:** limites de chamadas podem atender experimentos pessoais.

Confira a disponibilidade, as cotas e as condições atuais nos [provedores do diretório](http://freellms.org/).

## Recursos relacionados

- [Diretório de APIs gratuitas para LLM](http://freellms.org/)
- [Lista de APIs gratuitas compatíveis com OpenAI](http://freellms.org/)
- [Gateway de proxy de IA gratuito](http://freellms.org/)
- [Catálogo de modelos de LLM gratuitos](http://freellms.org/)
- [Agentes de IA gratuitos](http://freellms.org/)

## Licença e atualização

MIT. Segundo a fonte, as chaves e os links vêm de [freellms.org](http://freellms.org/) e o diretório é atualizado diariamente. Os limites reproduzidos acima são dados da origem e não uma promessa de disponibilidade vigente.

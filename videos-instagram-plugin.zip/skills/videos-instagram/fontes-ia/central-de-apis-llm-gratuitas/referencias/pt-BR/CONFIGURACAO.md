# Configuração das APIs

Use os exemplos como modelos. Confirme na documentação do provedor a URL-base, o modelo, os limites e o formato de autenticação. Nunca substitua o placeholder por uma chave em texto público.

## Python com SDK compatível com OpenAI

Instale a biblioteca oficial do cliente OpenAI em seu ambiente e configure a URL-base e a chave do provedor:

    from openai import OpenAI
    import os

    client = OpenAI(
        base_url="https://api.groq.com/openai/v1",
        api_key=os.environ["GROQ_API_KEY"],
    )

    resposta = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": "Olá!"}],
    )
    print(resposta.choices[0].message.content)

Os nomes de campo e a estrutura executável permanecem no formato aceito pelo SDK.

## Codex CLI

Em shells compatíveis com Bash, configure as variáveis de ambiente usando valores locais seguros:

    export OPENAI_BASE_URL="https://api.groq.com/openai/v1"
    export OPENAI_API_KEY="$SUA_CHAVE_GROQ"
    codex --model "llama-3.3-70b-versatile"

No Windows, use o método equivalente do seu terminal ou configure as variáveis no sistema. O nome da variável e o identificador do modelo devem corresponder ao cliente e ao provedor.

## Cursor

Abra Settings, depois Models, escolha Add Model e informe o provedor, URL-base, chave e identificador de modelo aceitos pelo Cursor. Os rótulos da interface podem variar com o idioma e a versão.

## Claude Code

Alguns provedores oferecem endpoint compatível com a API da Anthropic; outros roteadores expõem modelos Anthropic por uma API própria. Siga o guia oficial do provedor escolhido. Os exemplos de origem usam ANTHROPIC_BASE_URL, ANTHROPIC_AUTH_TOKEN e ANTHROPIC_API_KEY. Não combine chaves ou endpoints de provedores diferentes sem confirmar a configuração correta.

## Referências de configuração

- Claude Code: https://freellm.net/config/#claude-code
- Cursor: https://freellm.net/config/#cursor
- Codex: https://freellm.net/config/#codex
- OpenHuman: https://freellm.net/config/#openhuman
- OpenCode: https://freellm.net/config/#opencode
- OpenClaw: https://freellm.net/config/#openclaw
- Configurador geral: https://freellm.net/config/
- Lista de chaves e provedores: http://freellms.org/

Os códigos completos fornecidos nas fontes permanecem em fontes/originais/awesome-freellm-apis-main/awesome-freellm-apis-main/code-examples/.

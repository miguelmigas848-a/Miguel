# Fontes e preservação

Este pacote foi criado a partir dos cinco arquivos ZIP enviados pela pessoa usuária. Os arquivos extraídos estão representados em `fontes/originais/`, e os ZIPs originais permanecem intactos no local de origem; nomes e hashes SHA-256 estão registrados abaixo. Dois links relativos de arquivos que não vieram no ZIP do FreeLLM-API-KeyHub foram redirecionados às páginas oficiais do repositório. Os ZIPs brutos não estão aninhados no pacote de Skill, porque o importador rejeita ZIPs dentro do ZIP.

## Arquivos de origem

| Arquivo recebido | Conteúdo preservado |
|---|---|
| free-llm-api-keys-main.zip | Diretório de provedores de chaves gratuitas para APIs de LLM |
| awesome-claude-skills-main.zip | Catálogo comunitário de Skills, recursos e ferramentas para Claude |
| awesome-claude-skills-main (1).zip | Cópia byte a byte do ZIP acima |
| awesome-freellm-apis-main.zip | Catálogo de APIs, modelos, cotas, links de chaves e exemplos de configuração |
| FreeLLM-API-KeyHub-main.zip | Catálogo de provedores, ofertas promocionais e planos de programação |

Os dois ZIPs awesome-claude-skills têm SHA-256 F098CACF7930F957BF1E1C4C69793FDD3AF90D9C32B36857E3408B5A4347263D. Como são idênticos, seus arquivos extraídos são representados uma única vez em fontes/originais/.

| Arquivo ZIP recebido | SHA-256 |
|---|---|
| free-llm-api-keys-main.zip | 9ABE932AE322B5C510D7F61689E49F44E623E84452733AB44037E23151B6C317 |
| awesome-claude-skills-main.zip | F098CACF7930F957BF1E1C4C69793FDD3AF90D9C32B36857E3408B5A4347263D |
| awesome-claude-skills-main (1).zip | F098CACF7930F957BF1E1C4C69793FDD3AF90D9C32B36857E3408B5A4347263D |
| awesome-freellm-apis-main.zip | C345A3EF258E6E8DB30BE09053A830D31476C9E3836E35E9D2BA47E25336DFDD |
| FreeLLM-API-KeyHub-main.zip | C05C33308D9F6F4851F37834CBA2CC846F11D6D43B001C8B716B0B6810F4806B |

## Tradução

As referências de uso e as instruções da Skill foram redigidas em português brasileiro. Nomes de provedores, marcas, campos, códigos, comandos, modelos, URLs e identificadores de API permanecem na forma canônica para preservar compatibilidade. Licenças e documentos originais permanecem intactos; consulte as referências em português para usar o pacote.

## Observação de atualidade

Os materiais originais incluem cotas, preços e campanhas com datas específicas. Essas informações podem mudar. Antes de recomendar uma oferta como vigente, confira a página oficial do provedor e informe a data da consulta.
